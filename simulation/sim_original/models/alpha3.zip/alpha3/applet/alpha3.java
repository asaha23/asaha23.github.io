import processing.core.*; 
import processing.xml.*; 

import controlP5.*; 
import geomerative.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class alpha3 extends PApplet {

// Connected Chemistry Curriculum
// Project Leader: Mike Stieff, PhD, University of Illinois at Chicago
// Modeled in Processing by: Allan Berry
/*--------------------------------------------------------------------------*/

// imports
  
  
  
// variables
  String headerTitle;
  String headerSubtitle;
  PShape headerLogo;

  // units and dimensions
    float mod;      // setup a standard module size for graphics
    int   iMod;     // same as above, but as integer
  // main window
    int globalW;  // window width
    int globalH;  // window height

  // global locative variables
    public float globalScale;
    float globalScaleMin;
    float globalScaleDef;
    float globalScaleMax;
  
  // global time variables
    float globalTime;   // indicates the number of milliseconds since program start
    float globalFrameRate;
    public float globalSpeed;
    float globalSpeedMin;
    float globalSpeedDef;
    float globalSpeedMax;
    Boolean paused;
    float pauseStart;
    float pauseDuration;
    int[] moleculesPast;
    int baseSecond; // this is for making the internal model clock start with the number 0
    int previousSecond;
    int currentSecond; // actual second() - baseSecond
  
  // fonts
    PFont fontMyriadProBold22;
    PFont fontMyriadProCond12;
    PFont fontMyriadPro10;
    PFont fontMyriadPro12;
    PFont fontMyriadPro18;
    PFont fontMyriadPro22;
    
  // data
    Table elementTable; // main repository for element data
    int   elementTableRowCount;
    int[] elementNumber;
    String[] elementName;
    String[] elementSymbol;
    String[] elementColorName;
    int[] elementColorRed;
    int[] elementColorGreen;
    int[] elementColorBlue;
    //elementNameWaalsRadius;
    float[] elementAtomicRadius;
    float[] elementAtomicMass;

    Table reactionTable;
    int reactionTableRowCount;
    String[] reactant1;
    String[] reactant2;
    float[] reactProb;
    String[] reactResult1;
    String[] reactResult2;
    String[] reactResult3;
    
  // main molecule container
    Molecule[]  molecules;
    String[]    moleculeTypes;
    int[]       moleculeCount;
    int         secondsCounted;
    int[][]     moleculeCountPast;
    
  // GUI
    ControlP5   controlP5;  // GUI widget controller
    Slider      sliderScale;
    Slider      sliderSpeed;
    GButton    buttonAddMolecule0;
    GButton    buttonAddMolecule1;
    GButton    buttonRemoveMolecule;
    GWidget[]  widgets;
    //GButton[]  buttons;
    GControl[] moleculeControls;
    
    PShape button_arrow_small_down_down;
    PShape button_arrow_small_down_up;
    PShape button_arrow_small_left_down;
    PShape button_arrow_small_left_up;
    PShape button_arrow_small_right_down;
    PShape button_arrow_small_right_up;
    PShape button_arrow_small_up_down;
    PShape button_arrow_small_up_up;
    PShape button_minus_up;
    PShape button_pause_down;
    PShape button_pause_up;
    PShape button_play_down;
    PShape button_play_up;
    PShape button_plus_up;
    PShape button_reset_down;
    PShape button_reset_up;

  // Grid
  // column 1
    float gridCol1X;
    float gridCol1W;
  // column 2
    float gridCol2X;
    float gridCol2W;
  // row 1
    float gridRow1Y;
    float gridRow1H;
  // row 2
    float gridRow2Y;
    float gridRow2H;
  // row 3
    float gridRow3Y;
    float gridRow3H;
  // canvas
    float canvasTop;
    float canvasRight;
    float canvasBottom;
    float canvasLeft;
  
  // molecule quantity defaults; used by molecule tracking plot & ControlP5
    int   moleculeQntyMin;
    int   moleculeQntyDef;
    int   moleculeQntyMax;
    int   moleculeQntyTotal;
    
  // colors
    int cFill_Bg;
    int cFill_Canvas;
    int cFill_Widget;
    int cStrk_Widget;
    int cStrk_Default;
    int cFill_Atom;
    int cStrk_Atom;
    int cText;

    int[] cPlot;
    
  //sin and cos look-up tables  
    // declare arrays and params for storing sin/cos values 
    float sinLUT[];
    float cosLUT[];
    float SC_PRECISION;  // set table precision to 0.5 degrees
    float SC_INV_PREC;  // caculate reciprocal for conversions
    int SC_PERIOD;  // compute required table length

public void setup() {
  // bootstrap
    //setColors();
    setDefaultVars();
    setElementTable();
    setReactionTable();
    setSinCos(); // important call to initialize lookup tables

    size(864, 672);
    frameRate(globalFrameRate);
    smooth();
    
  // set main systems
    setGlobalScale(globalScaleDef);
    setGlobalSpeed(globalSpeedDef);
    setTime();
    
    moleculeCount = new int[moleculeTypes.length];
    secondsCounted = 60;
    moleculeCountPast = new int[moleculeTypes.length][secondsCounted];
    
  // initialize molecule container
    molecules = new Molecule[moleculeTypes.length * moleculeQntyMax +1]; // allow molecules up to a certain threshold
    for (int i = 0; i < moleculeTypes.length; i++) {
      // populate molecules[]
      for (int j = 0; j < moleculeQntyDef; j++) {
        appendMolecule(moleculeTypes[i], random(canvasLeft, canvasRight), random(canvasTop, canvasBottom));
      }
    };
  
  // set gui  
    setFonts();
    setSVGs();
    setWidgets();
    setControls();
    setColours();
    setGeomerative("init");
    setControlP5("init");
};
  
public void draw() {
  globalTime = millis();
  drawBg(); // main background
  drawCanvasBg();
  // column 2
    for (int i = 0; i < moleculeQntyTotal ; i++) {
      molecules[i].update();
      molecules[i].display();
    }
  
  // column 1 (occludes molecules when they overlap column 2)
  drawCol1Bg();
  // label
  // widgets
  for (int i = 0; i < widgets.length; i++) {
    widgets[i].display();
  };
  // controls
  for (int i = 0; i < moleculeControls.length; i++) {
    moleculeControls[i].update();
    moleculeControls[i].display();
  };
  // buttons
  /*for (int i = 0; i < buttons.length; i++) {
    buttons[i].display();
  };*/
  drawHeaderText();
  setControlP5("label");
  countSeconds();
  setMoleculeQntyPast();
  
  setControlText();  // this will need to be integrated in the widget class... too busy now
};
public class Atom {
// Atoms are totally subservient to Molecules, and operate relative to a molecule's origin, i.e. molecule.location
  
  //variables
    int     atomID;
    
    // elemental variables
    String  atomName;  // e.g. "Hydrogen"
    int     atomNumber;
    String  atomSymbol;
    String  atomColorName;
    int     atomColorRed;
    int     atomColorGreen;
    int     atomColorBlue;
    //float elementWaalsRadius;
    float   atomRadius;
    float   atomMass;
    
    String  ion;          // in form "+1" or "-2" for charge of particle
    
    // locative variables
    float   originDist;   // distance to origin of molecule
    float   originTheta;  // relative to origin of molecule
    int   atomFill = cFill_Atom;
    int   atomStrk = cStrk_Atom;
  
  // constructor
  public Atom(int atomicNum_) {
    atomNumber = atomicNum_;
    
    initAtomData(atomNumber);
  }
  
  // methods  
    public void initAtomData(int atomNumber) {
      int i = atomNumber-1;
      atomName = elementName[i];
      atomSymbol = elementSymbol[i];
      atomColorName = elementColorName[i];
      atomColorRed = elementColorRed[i];
      atomColorGreen = elementColorGreen[i];
      atomColorBlue = elementColorBlue[i];
      //elementWaalsRadius;
      atomRadius = elementAtomicRadius[i];
      atomMass = elementAtomicMass[i];
      
      atomFill = color(atomColorRed, atomColorGreen, atomColorBlue);
      atomStrk = cStrk_Atom;
    };
    
    // locative methods
    public void setAtomicRadius() {};
    public void setOriginDist() {};
    public void setOriginTheta() {};

    // electron methods
    public void setElectrons() {};
}
public class GButton {
  // variables
  int     buttonID;
  
  // locative variables
  float   buttonX;
  float   buttonY;
  float   buttonW;
  float   buttonH;
  
  // display variables
  boolean buttonFill = true; // widget has background
  boolean buttonStrk = true; // widget has outline
  int   fillDefault = color(0, 75, 75);
  int   fillColor   = fillDefault;
  int   strokeColor = cStrk_Widget;
  
  // label variables
  String  labelText;
  int   labelColor;
  float   labelX;
  float   labelY;
  
  // interactivity
  boolean mouseOver;
  boolean mouseDown;
  int fillMouseOver = color(127, 0, 0);
  int fillMouseDown = color(200, 0, 0);
  
  // constructor
  public GButton(float buttonX_, float buttonY_, float buttonW_, float buttonH_) {
    buttonX = buttonX_;
    buttonY = buttonY_;
    buttonW = buttonW_;
    buttonH = buttonH_;
    
    setVars();
  }
  
  // methods
  public void display() {
    pushStyle();
    detectMouseOver();
      fill(fillColor);
      rect(buttonX, buttonY, buttonW, buttonH);
    popStyle();
    
    drawLabels();
  }
  // methods
  public void setVars() {
    labelX = buttonX + mod/4;    
    labelY = buttonY + mod/3;
    labelColor = color(255, 255, 255);
  }
  
  public void detectMouseOver() {
    if (mouseX > buttonX && mouseX < buttonX + buttonW && mouseY > buttonY && mouseY < buttonY + buttonH) {
      mouseOver = true;
      if (mousePressed == true) {
        fillColor = fillMouseDown;
      } else {
        fillColor = fillMouseOver;
      }
    } else {
      mouseOver = false;
      fillColor = fillDefault;
    }
  }
/*----------------------------------------------------------------------------*/
// labels
  public void drawLabels() {
    pushStyle();
      fill(labelColor);
      if (labelText != null) {
          text(labelText, labelX, labelY);
      }
    popStyle();
  };
}
public class GControl {
  // variables
  int     controlID;
  String  controlType;
  String  controlSubtype;
  String  controlState = "up";
  
  // locative variables
  float   controlX;
  float   controlY;
  float   controlW;
  float   controlH;
  
  float activeAreaX;
  float activeAreaY;
  float activeAreaW;
  float activeAreaH;
  
  // display variables
  boolean controlFill = true; // widget has background
  boolean controlStrk = true; // widget has outline
  
  // label variables
  String  labelText;
  float   labelX;
  float   labelY;
  
  PShape buttonIcon;  

  
  int cFillMainUp = color(127, 127, 127);
  int cFillMainOver = color(157, 157, 157);
  int cFillMainActive = color(234, 91, 12);
  int cFillMainDown = color(176, 69, 23);
  int cFillMain = cFillMainUp;
  
  int cStrkMainUp = color(100, 100, 100);
  int cStrkMainOver = color(178, 178, 178);
  int cStrkMainActive = color(204, 69, 23);
  int cStrkMainDown = color(154, 52, 21);
  int cStrkMain = cStrkMainUp;
  
  int cFillHandleUp = color(51, 94, 127);
  int cFillHandleOver = color(51, 94, 190);
  int cFillHandleActive = color(81, 186, 230);
  int cFillHandleDown = color(38, 169, 224);
  int cFillHandle = cFillHandleUp;
  
  int cStrkHandleUp = color(43, 56, 143);
  int cStrkHandleOver = color(43, 56, 189);
  int cStrkHandleActive = color(73, 145, 201);
  int cStrkHandleDown = color(27, 117, 187);
  int cStrkHandle = cStrkHandleUp;
  
  int cFillDim = color(127);
  int cStrkDim = color(110);
  int cTextDim = color(166);
  
  int cTextLabel = color(255);
  int cStrkShadow = color(90, 127);
  int cStrkHilite = color(255, 25);
  
  // constructor
  public GControl(String controlType_, float controlX_, float controlY_, float controlW_, float controlH_) {
    controlType = controlType_;
    controlX = controlX_;
    controlY = controlY_;
    controlW = controlW_;
    controlH = controlH_;
    init();
  }
  
  // methods
  public void init() {
    labelX = controlX + mod/4;    
    labelY = controlY + mod/3;
    setActiveArea();
  }
  
  public void update() {
    detectMouseOver();
    setControlColors();
    setOverrides();
    if (controlSubtype.equals("add molecule")) {
      buttonIcon = button_plus_up;
    }
    if (controlSubtype.equals("remove molecule")) {
      buttonIcon = button_minus_up;
    }
  }

  public void display() {
    pushStyle();
      fill(cFillMain);
      stroke(cStrkMain);
      rect(controlX, controlY, controlW, controlH);
      shapeMode(CENTER);
      shape(buttonIcon, controlX + controlW/2, controlY + controlW/2, mod, mod);
    popStyle();
  }
  
  public void setActiveArea() {
    if (controlType == "button") {
        activeAreaX = controlX;
        activeAreaY = controlY;
        activeAreaW = controlW;
        activeAreaH = controlH;
    } else if (controlType == "slider") {
        activeAreaX = controlX;
        activeAreaY = controlY;
        activeAreaW = controlW;
        activeAreaH = controlH;
    } else if (controlType == "ball slider") {
        activeAreaX = controlX;
        activeAreaY = controlY;
        activeAreaW = controlW;
        activeAreaH = controlH;
    } else if (controlType == "pulldown") {
        activeAreaX = controlX;
        activeAreaY = controlY;
        activeAreaW = controlW;
        activeAreaH = controlH;
    } else if (controlType == "switch") {
        activeAreaX = controlX;
        activeAreaY = controlY;
        activeAreaW = controlW;
        activeAreaH = controlH;
    }
  }
  
  public void setControlColors() {
    if (controlState == "over") {
      cFillMain   = cFillMainOver;
      cStrkMain   = cStrkMainOver;
      cFillHandle = cFillHandleOver;
      cStrkHandle = cStrkHandleOver;
    } else if (controlState == "active") {
      cFillMain   = cFillMainActive;
      cStrkMain   = cStrkMainActive;
      cFillHandle = cFillHandleActive;
      cStrkHandle = cStrkHandleActive;
    } else if (controlState == "down") {
      cFillMain   = cFillMainDown;
      cStrkMain   = cStrkMainDown;
      cFillHandle = cFillHandleDown;
      cStrkHandle = cStrkHandleDown;
    } else { /* up */
      cFillMain   = cFillMainUp;
      cStrkMain   = cStrkMainUp;
      cFillHandle = cFillHandleUp;
      cStrkHandle = cStrkHandleUp;
    }
  };
  
  public void setOverrides() {
    if (controlSubtype == "add molecule") {
      if (controlState == "over") {
        cFillMain   = color(74, 186, 127);
        cStrkMain   = color(86, 222, 98);
      } else if (controlState == "active") {
        cFillMain   = color(43, 199, 0);
        cStrkMain   = color(0, 148, 13);
      } else { /* up */
        cFillMain   = color(51, 128, 88);
        cStrkMain   = color(67, 172, 76);
      }
    }    
    if (controlSubtype == "remove molecule") {
      if (controlState == "over") {
        cFillMain   = color(201, 52, 68);
        cStrkMain   = color(255, 82, 98);
      } else if (controlState == "active") {
        cFillMain   = color(255, 0, 22);
        cStrkMain   = color(191, 0, 17);
      } else { /* up */
        cFillMain   = color(128, 51, 59);
        cStrkMain   = color(189, 31, 45);
      }
    }
  }
  

  
  public void detectMouseOver() {
    if (mouseX > activeAreaX && mouseX < activeAreaX + activeAreaW && mouseY > activeAreaY && mouseY < activeAreaY + activeAreaH) {
      if (mousePressed == true) {
        controlState = "active";
      } else {
        controlState = "over";
      }
    } else {
      controlState = "up";
    }
  }
/*----------------------------------------------------------------------------*/
// labels
  public void drawLabels() {
    pushStyle();
      fill(cTextLabel);
      if (labelText != null) {
          text(labelText, labelX, labelY);
      }
    popStyle();
  };

}
public class GWidget {
  // variables
    int       widgetID;
    String    widgetType;   // e.g. "Plot"
    
    // locative variables
    float   widgetX;
    float   widgetY;
    float   widgetW;
    float   widgetH;
    
    // display variables
    boolean widgetFill = true; // widget has background
    boolean widgetStrk = true; // widget has outline
    int   fillColor = cFill_Widget;
    int   strokeColor = cStrk_Widget;
    
    // label variables
    String  labelText;
    int   labelColor;
    float   labelX;
    float   labelY;
    
    // plot variables
    float incrementsX = secondsCounted;
    float incrementsY = moleculeQntyMax;
  
  // constructor
  public GWidget(String widgetType_, float widgetX_, float widgetY_, float widgetW_, float widgetH_) {
    widgetType = widgetType_;
    widgetX = widgetX_;
    widgetY = widgetY_;
    widgetW = widgetW_;
    widgetH = widgetH_;
    
    setVars(widgetType);
    
    if (widgetType == "Plot") {
      // make room for labels
      widgetW = widgetW - mod/2;
      widgetH = widgetH - mod/2;
    }
  };

  // methods
  public void setVars(String widgetType) {
    labelX = widgetX + mod*.25f;    
    labelY = widgetY + mod*.5f;
    labelColor = color(255, 255, 255);
  }
  public void setLocation() {}
  public void display() {
    drawBackground();
    drawVis();
    drawStroke(); // stroke and labels should be drawn after visualization
    drawLabels();
  }
  
/*----------------------------------------------------------------------------*/
// visualization

  public void drawVis() {
    pushMatrix();
    translate(widgetX, widgetY);
    pushStyle();
    if (widgetType == "Plot") {
      fill(255, 0, 0);
      for (int i = 0; i < incrementsX; i++) {
        for (int ii = 0; ii < moleculeTypes.length; ii++) {
          fill(cPlot[ii]);
          ellipse(widgetW - (widgetW/incrementsX * i), widgetH - widgetH/incrementsY * moleculeCountPast[ii][i], 3, 3);
        }
      }
    }
    popStyle();
    popMatrix();
  }

/*----------------------------------------------------------------------------*/
// box
  public void drawBackground() {
    textFont(fontMyriadPro12, 12);
    if (widgetFill == true) {
      pushStyle();
        fill(fillColor);
        noStroke();
        rect(widgetX, widgetY, widgetW, widgetH);
      popStyle();
    }
  };
  
  public void drawStroke() {
    if (widgetStrk == true) {
      pushStyle();
        noFill();
        // frame, to mask a little of line overlap
        stroke(cFill_Bg);
        strokeWeight(3);
        rect(widgetX - 2, widgetY - 2, widgetW + 4, widgetH + 4);
        stroke(strokeColor);
        strokeWeight(1);
        rect(widgetX, widgetY, widgetW, widgetH);
      popStyle();
    }
  }

/*----------------------------------------------------------------------------*/
// labels
  public void drawLabels() {
    pushStyle();
    fill(labelColor);
    if (labelText != null) {
        text(labelText, labelX, labelY);
    }
    // type centric
    if (widgetType == "Plot") {
      // x axis
      textAlign(LEFT);
      text("60", widgetX, widgetY + widgetH + mod/3);
      textAlign(CENTER);
      text("time, in seconds", widgetX + widgetW/2, widgetY + widgetH + mod/3);
      textAlign(RIGHT);
      text("Now", widgetX + widgetW, widgetY + widgetH + mod/3);
      
      // y axis
      textAlign(LEFT);
      text(str(moleculeQntyMax), widgetX + widgetW + mod/6, widgetY + mod/4);
      pushMatrix();
        textAlign(CENTER);
        translate(widgetX + widgetW + mod/3, widgetY + widgetH/2);
        rotate(PI/2*-1);
        text("# of molecules", 0, 0);
      popMatrix();
      textAlign(LEFT);
      text(str(moleculeQntyMin), widgetX + widgetW + mod/6, widgetY + widgetH);
    }    
    popStyle();
  };
};
public class Molecule {
  
  //after implementation with sin/cos, consult http://wiki.processing.org/w/Sin/Cos_look-up_table
  
  // variables
    int       moleculeID;
    
    // reactions
    int       spouse;  // only gets filled upon molecule reaction; the ID of the molecule it is reacting with
    
    // molecular variables
    String    moleculeName;   // e.g. "Water"
    String    moleculeComp;   // e.g. "H2O", or rather "H<sub>2</sub>O";
                              // use <sub> for subscript, <sup> for superscript

    // locative variables
    PShape    mShape;
    float     mScale = 1;
    PVector   loc;
    PVector   dir;
    PVector   velSpeedAdj;
    PVector   vel = new PVector(random(-.5f, .5f), random(-.5f, .5f));
    PVector   acc = new PVector(0,0);
    float     topSpeed = 10;
    float     rotation      = random(0, 2); // current absolute rotation: default .2 rad, i.e. 1 rotation/second
    float     rotationRate  = random(.05f, .3f);   // rate of rotation
    float[]   molDist;
    float[]   reactProb;    // list of the raction probability with different molecules
                            // Default: 1.0.  This should probably be converted to a hashmap
    float pH;     // optional; pH of concentrated compound
    float moleculeRadius = 30;
    float contourRadius;  // dependent on scale
  
  // constructor
  public Molecule(String moleculeName_, float xLoc_, float yLoc_) {
    moleculeName = moleculeName_;
    loc = new PVector(xLoc_, yLoc_);
    mShape = loadShape("svg/" + moleculeName.replace(" ", "-") + ".svg");
    moleculeID = getHighestID() + 1;
    setContourRadius(moleculeName);
  }
  
  // methods
    //locative methods
    
    public void init() {};
    public void update() {
      if (vel.x != 0 && vel.y != 0) {
        dir = vel.get();
      }
      dir.normalize();
      velSpeedAdj = dir.get();
      velSpeedAdj.mult(globalSpeed);
      vel.add(velSpeedAdj);
      
      vel.add(acc);
      vel.limit(topSpeed * globalSpeed);
      loc.add(vel);
      
      contourRadius = moleculeRadius * globalScale;
      rotation = rotation + rotationRate * globalSpeed;
      mScale = globalScale;
      wallBounce();
    };
    public void display() {
      pushMatrix();
      translate(loc.x, loc.y);
      rotate(rotation);
        shape(mShape, mShape.width * mScale/-2, mShape.height * mScale/-2, mShape.width * mScale, mShape.height * mScale);
       /*pushStyle(); // this shows contour circle  // this stuff will draw a radius for debugging
          noFill();
          stroke(255);
          ellipse(0, 0, contourRadius*2, contourRadius*2);
        popStyle();*/
      popMatrix();
      reaction();
    };
    
    public void setContourRadius(String moleculeName) {
           if (moleculeName == "Water") {moleculeRadius = 30;}
      else if (moleculeName == "Acetic Acid") {moleculeRadius = 60;}
      else if (moleculeName == "Bromide") {moleculeRadius = 25;}
      else if (moleculeName == "Hydrogen Chloride") {moleculeRadius = 30;}
      else if (moleculeName == "Sodium Acetate") {moleculeRadius = 60;}
      else if (moleculeName == "Sodium Chloride") {moleculeRadius = 60;}
      else if (moleculeName == "Sodium Hydroxide") {moleculeRadius = 60;}
      
         else {moleculeRadius = 30;}
    }
    
    public void wallBounce() {
      // bounce into canvas edges
      if (loc.x - contourRadius < canvasLeft) {
        revDirX();
        revRotation();
        loc.x = loc.x + .2f;
      };
      if (loc.x + contourRadius > canvasRight) {
        revDirX();
        revRotation();
        loc.x = loc.x - .2f;
      };
      if (loc.y - contourRadius < canvasTop) {
        revDirY();
        revRotation();
        loc.y = loc.y + .2f;
      };
      if (loc.y + contourRadius > canvasBottom) {
        revDirY();
        revRotation();
        loc.y = loc.y - .2f;
      };
    };
    
    public void revDirY()      { vel.y = vel.y * -1; }
    public void revDirX()      { vel.x = vel.x * -1; }
    public void revRotation()  { rotationRate = rotationRate * -1; }
    public void setRotation()  { rotation = rotation + rotationRate; }
    
    public void bounce(Molecule otherMolecule) {
      PVector velTmp = new PVector(vel.x, vel.y);
      float rotTmp = rotationRate;
      vel = otherMolecule.vel.get();
      rotationRate = otherMolecule.rotationRate;
      otherMolecule.rotationRate = rotTmp;
      otherMolecule.vel = velTmp.get();
      PVector interMolDir = PVector.sub(loc, otherMolecule.loc);
      if (interMolDir.x > 0) {
        loc.x = loc.x + .25f;
      }
      if (interMolDir.x < 0) {
        loc.x = loc.x - .25f;
      }
      if (interMolDir.y > 0) {
        loc.y = loc.y + .25f;
      }
      if (interMolDir.y < 0) {
        loc.y = loc.y - .25f;
      }
    }
    
    public boolean compatibleWith(Molecule otherMolecule) {
      for (int i = 0; i < reactionTableRowCount; i++) {
        if (moleculeName.equals(reactant1[i]) && otherMolecule.moleculeName.equals(reactant2[i]) || moleculeName.equals(reactant2[i]) && otherMolecule.moleculeName.equals(reactant1[i])) {
          return true;
        }
      }  
      return false;
    }
    
    public void reaction() {
      for (int i = 0; i < moleculeQntyTotal; i++) {
        float distance = loc.dist(molecules[i].loc);
        // check to see how close together
        if (distance < contourRadius + molecules[i].contourRadius && molecules[i].moleculeID != moleculeID) {
          // check to see if suitable mate
          if (spouse == 0 && molecules[i].spouse == 0  && compatibleWith(molecules[i]) == true) { // check to see if self can mate... this needs to be fixed to account for "none" values in table

            removeMoleculeByID(molecules[i].moleculeID);
            removeMoleculeByID(moleculeID);
            
            appendMolecule("Hydrogen Cyanide", loc.x, loc.y);
            appendMolecule("Bromide", loc.x, loc.y);
          } else { 
            bounce(molecules[i]);
          }
        }
      }
    }
}
// This code from the Processing Table class.  Has not been altered.

class Table {
  int rowCount;
  String[][] data;


  Table(String filename) {
    String[] rows = loadStrings(filename);
    data = new String[rows.length][];

    for (int i = 0; i < rows.length; i++) {
      if (trim(rows[i]).length() == 0) {
        continue; // skip empty rows
      }
      if (rows[i].startsWith("#")) {
        continue;  // skip comment lines
      }

      // split the row on the tabs
      String[] pieces = split(rows[i], TAB);
      // copy to the table array
      data[rowCount] = pieces;
      rowCount++;

      // this could be done in one fell swoop via:
      //data[rowCount++] = split(rows[i], TAB);
    }
    // resize the 'data' array as necessary
    data = (String[][]) subset(data, 0, rowCount);
  }


  public int getRowCount() {
    return rowCount;
  }


  // find a row by its name, returns -1 if no row found
  public int getRowIndex(String name) {
    for (int i = 0; i < rowCount; i++) {
      if (data[i][0].equals(name)) {
        return i;
      }
    }
    println("No row named '" + name + "' was found");
    return -1;
  }


  public String getRowName(int row) {
    return getString(row, 0);
  }


  public String getString(int rowIndex, int column) {
    return data[rowIndex][column];
  }


  public String getString(String rowName, int column) {
    return getString(getRowIndex(rowName), column);
  }


  public int getInt(String rowName, int column) {
    return parseInt(getString(rowName, column));
  }


  public int getInt(int rowIndex, int column) {
    return parseInt(getString(rowIndex, column));
  }


  public float getFloat(String rowName, int column) {
    return parseFloat(getString(rowName, column));
  }


  public float getFloat(int rowIndex, int column) {
    return parseFloat(getString(rowIndex, column));
  }


  public void setRowName(int row, String what) {
    data[row][0] = what;
  }


  public void setString(int rowIndex, int column, String what) {
    data[rowIndex][column] = what;
  }


  public void setString(String rowName, int column, String what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = what;
  }


  public void setInt(int rowIndex, int column, int what) {
    data[rowIndex][column] = str(what);
  }


  public void setInt(String rowName, int column, int what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = str(what);
  }


  public void setFloat(int rowIndex, int column, float what) {
    data[rowIndex][column] = str(what);
  }


  public void setFloat(String rowName, int column, float what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = str(what);
  }  
}


// default variable and immediate derivative input
public void setDefaultVars() {
  // variables
  
  
  headerTitle = "Connected Chemistry";
  headerSubtitle = "Unit 3:Acids & Bases, Lesson ?";
  
  // initialize molecule types and provide means to count them
  moleculeTypes = new String[4];
  moleculeTypes[0] = "Cyanide Ion";
  moleculeTypes[1] = "Hydrogen Bromide";
  moleculeTypes[2] = "Hydrogen Cyanide";
  moleculeTypes[3] = "Bromide";
  
  // units and dimensions
  mod             = 48;           // setup a standard module size for graphics
  iMod            = floor(mod);   // same as above, but as integer
  globalW         = iMod * 18;    // main window width
  globalH         = iMod * 14;    // main window height
  globalFrameRate = 30;

  // GUI
  // Grid
  // column 1
    gridCol1X     = 0;
    gridCol1W     = mod * 6;
  // column 2
    gridCol2X     = gridCol1W;
    gridCol2W     = globalW - gridCol1W;
  // row 1
    gridRow1Y     = 0;
    gridRow1H     = mod * 13;
  // row 2
    gridRow2Y     = gridRow1H;
    gridRow2H     = globalH - gridRow1H;
  // canvas
    canvasTop     = 0;
    canvasRight   = globalW;
    canvasBottom  = globalH - gridRow2H;
    canvasLeft    = gridCol2X;
    
  // sin cos lookup tables
    SC_PRECISION = 0.5f;  // set table precision to 0.5 degrees
    SC_INV_PREC = 1/SC_PRECISION;  // caculate reciprocal for conversions
    SC_PERIOD = (int) (360f * SC_INV_PREC);  // compute required table length

  // global locative variables
    globalScaleMin    = .05f;
    globalScaleDef    = .5f;
    globalScaleMax    = 1;

  // global time variables
    globalFrameRate   = 30;
    globalSpeedMin    = 0;
    globalSpeedDef    = .25f;
    globalSpeedMax    = .5f;
    paused            = false;
    pauseStart        = 0;
    pauseDuration     = 0;

  // fontscontrolP5Font

  // molecule quantity defaults; used by molecule tracking plot & ControlP5
    moleculeQntyMin   = 0;
    moleculeQntyDef   = 0;
    moleculeQntyMax   = 50;
  
  // colors
    cFill_Bg          = color(150);
    cFill_Canvas      = color(110);
    cFill_Widget      = color(100);
    cStrk_Widget      = color(193);
    cStrk_Default     = color(0);
    cFill_Atom        = color(255);
    cStrk_Atom        = color(0);
    cText             = color(255);
};
// math
  // init sin/cos tables with values
  // should be called from setup()
  public void setSinCos() {
    sinLUT = new float[SC_PERIOD];
    cosLUT = new float[SC_PERIOD];
    for (int i = 0; i < SC_PERIOD; i++) {
      sinLUT[i] = (float) Math.sin(i * DEG_TO_RAD * SC_PRECISION);
      cosLUT[i] = (float) Math.cos(i * DEG_TO_RAD * SC_PRECISION);
    }
  }

/*----------------------------------------------------------------------------*/

// data
  public void setElementTable() {
    elementTable = new Table("data/elements.tsv");
    elementTableRowCount = elementTable.getRowCount();
    
    elementNumber       = new int[elementTableRowCount];
    elementName         = new String[elementTableRowCount];
    elementSymbol       = new String[elementTableRowCount];
    elementColorName    = new String[elementTableRowCount];
    elementColorRed     = new int[elementTableRowCount];
    elementColorGreen   = new int[elementTableRowCount];
    elementColorBlue    = new int[elementTableRowCount];
    //elementNameWaalsRadius;
    elementAtomicRadius = new float[elementTableRowCount];
    elementAtomicMass   = new float[elementTableRowCount];
    
    for (int row = 0; row < elementTableRowCount; row++) {
      // natural lists
      elementNumber[row]        = elementTable.getInt(row, 0);     // column 1
      elementName[row]          = elementTable.getString(row, 1);     // column 2
      elementSymbol[row]        = elementTable.getString(row, 2);     // column 3
      elementColorName[row]     = elementTable.getString(row, 3);     // column 4
      elementColorRed[row]      = elementTable.getInt(row, 4);     // column 5
      elementColorGreen[row]    = elementTable.getInt(row, 5);     // column 6
      elementColorBlue[row]     = elementTable.getInt(row, 6);     // column 7
      //elementNameWaalsRadius[row] = elementTable.getString(row, 7);     // column 8
      elementAtomicRadius[row]  = elementTable.getFloat(row, 8);     // column 9
      elementAtomicMass[row]    = elementTable.getFloat(row, 9);     // column 10
    };
  }
  
  public void setReactionTable() {
    reactionTable = new Table("data/reactions.tsv");
    reactionTableRowCount = reactionTable.getRowCount();
    
    reactant1     = new String[reactionTableRowCount];
    reactant2     = new String[reactionTableRowCount];
    reactProb     = new float[reactionTableRowCount];
    reactResult1  = new String[reactionTableRowCount];
    reactResult2  = new String[reactionTableRowCount];
    reactResult3  = new String[reactionTableRowCount];
    
    for (int row = 0; row < reactionTableRowCount; row++) {
      reactant1[row]    = reactionTable.getString(row, 0);
      reactant2[row]    = reactionTable.getString(row, 1);
      reactProb[row]    = reactionTable.getFloat(row, 2);
      reactResult1[row] = reactionTable.getString(row, 3);
      reactResult2[row] = reactionTable.getString(row, 4);
      reactResult3[row] = reactionTable.getString(row, 5);
    }
  }

/*----------------------------------------------------------------------------*/
// space and time
  public void setGlobalScale(float input) {
    globalScale = input;
  }
  public void setGlobalSpeed(float input) {
    globalSpeed = input;
  }
  public void setTime() {
    currentSecond = 0; // nonsense init variable, to substitute for null
    moleculesPast = new int[60]; // an array with a slot for each passed second
  }
  
  public void countSeconds() {
    previousSecond = currentSecond;
    currentSecond = floor(millis()/1000);
  }
  public void updateTime() {};
  public void setPause() {}
  
/*----------------------------------------------------------------------------*/

// control P5
  public void setControlP5(String action) {
    pushStyle();
    if (action == "init") {
      controlP5     = new ControlP5(this);  // GUI widget controller
    }
      // position and other variables
      int tmpX = iMod*8;
      int tmpY = globalH - PApplet.parseInt(mod*.75f);
      int tmpW = iMod*4;
      int tmpH = iMod/2;
      textFont(fontMyriadPro12, 12);
      fill(cText);
      
    // global scale slider
    if (action == "init") {
    sliderScale = controlP5.addSlider("globalScale", globalScaleMin,  globalScaleMax,  globalScaleDef,  tmpX + iMod/4 - iMod/2, tmpY, tmpW, tmpH);
      sliderScale.captionLabel().set(""); // override controlP5 labels BECAUSE THEY DON'T FUCKING WORK
    } else if (action == "label") {
      textAlign(RIGHT);
      text("Graphic Size", tmpX - iMod/2, globalH - mod/3);
    }
    
    // global speed slider
    if (action == "init") {
    sliderSpeed = controlP5.addSlider("globalSpeed", globalSpeedMin,  globalSpeedMax,  globalSpeedDef,  tmpX + iMod*6 + iMod/4 - iMod/2, tmpY, tmpW, tmpH);
      sliderSpeed.captionLabel().set(""); // override controlP5 labels BECAUSE THEY DON'T FUCKING WORK
    } else if (action == "label") {
      textAlign(RIGHT);
      text("Global Speed", tmpX + iMod*6 - iMod/2, globalH - mod/3);
    }
    popStyle();
  }

/*----------------------------------------------------------------------------*/

// Geomerative
  public void setGeomerative(String action) {
    if (action == "init") {
      RG.init(this);
    }
  }

/*----------------------------------------------------------------------------*/


// native gui elements
  
  public void setControls() {
    moleculeControls = new GControl[moleculeTypes.length * 2];
    
    float mGroupX = mod*4;
    float mGroupY = mod*3;
    float mMargin = mod/8;
    
    float bX;
    float bY = mGroupY;
    float bW = mod*.5f;
    float bH = mod*.5f;
    

    
    // individual buttons
    for (int i = 0; i < moleculeControls.length; i++) {
      bX = mGroupX; // resets each iteration
      
      // columns (add or remove): provide X values
      if (i % 2 == 0)
        {} // "add" buttons; no change
      else
        {bX = mGroupX + bW + mMargin;} // "remove" buttons
        
      // rows (by molecule name): provide Y values
      if (i % 2 == 0 && i > 0)
        {bY = bY + bH + mMargin;}
        
      moleculeControls[i] = new GControl("button", bX, bY, bW, bH);
      if (i % 2 == 0) {
        moleculeControls[i].controlSubtype = "add molecule";
      } else {
        moleculeControls[i].controlSubtype = "remove molecule";
      }
    }
  };
  
  public void setControlText() {
    pushStyle();
    fill(color(255));
      textAlign(LEFT);
      textFont(fontMyriadPro12, 12);
      float yPos = mod * 3.5f;
      float yPosOffset = mod * .6f;
      text(moleculeTypes[0] + "   " + str(moleculeCount[0]), mod, yPos + yPosOffset*0); // text for buttons here
      text(moleculeTypes[1] + "   " + str(moleculeCount[1]), mod, yPos + yPosOffset*1);
      text(moleculeTypes[2] + "   " + str(moleculeCount[2]), mod, yPos + yPosOffset*2);
      text(moleculeTypes[3] + "   " + str(moleculeCount[3]), mod, yPos + yPosOffset*3);
      
    fill(cPlot[0]);
    rect(mod - mod/2,  yPos + yPosOffset*0 - mod/4, mod/4, mod/4);
    
    fill(cPlot[1]);
    rect(mod - mod/2,  yPos + yPosOffset*1 - mod/4, mod/4, mod/4);
    
    fill(cPlot[2]);
    rect(mod - mod/2,  yPos + yPosOffset*2 - mod/4, mod/4, mod/4);
    
    fill(cPlot[3]);
    rect(mod - mod/2,  yPos + yPosOffset*3 - mod/4, mod/4, mod/4);
      
      
    popStyle();
    
    
    
    
  }
  
  public void setWidgets() {
    widgets = new GWidget[2];
    // pH Gauge
      widgets[0] = new GWidget("Gauge", mod/4, globalH - mod*6.5f, mod*5.5f, mod*2);
      widgets[0].labelText = "pH Level";
    // molecule quantity plot
      widgets[1] = new GWidget("Plot", mod/4, globalH - mod*4.25f, mod*5.5f, mod*4);
      widgets[1].labelText = "Molecule Quantity";
  };
  
  public void setColours() {
    cPlot = new int[6];
    cPlot[0] = color(255, 255, 63, 200);
    cPlot[1] = color(38, 169, 224, 200);
    cPlot[2] = color(55, 179, 74, 200);
    cPlot[3] = color(246, 146, 30, 200);
    cPlot[4] = color(236, 28, 36, 200);
  };

  public void drawBg() {
    pushStyle();
      fill(cFill_Bg);
      rect(0, 0, globalW, globalH);
    popStyle();
  }
  public void drawCanvasBg() {
    pushStyle();
      fill(cFill_Canvas);
      rect(canvasLeft, canvasTop, canvasRight, canvasBottom);
    popStyle();
  }
  public void drawCol1Bg() {
    pushStyle();
      fill(cFill_Bg);
      rect(0, 0, gridCol1W, globalH);
    popStyle();
  }
  public void drawHeaderText() {
    pushStyle();
    fill(cText);
      textFont(fontMyriadProBold22, 22);
      text(headerTitle, mod/4, mod/2);
      
      textFont(fontMyriadPro12, 12);
      text(headerSubtitle, mod/4, mod);
    popStyle();
    pushMatrix();
    translate(mod*5, mod/2);
      shape(headerLogo, headerLogo.width * -.5f, headerLogo.height * -.5f, headerLogo.width, headerLogo.height);
    popMatrix();
  }
  public void popupContextMenu() {};
  
  public void setSVGs() {
    headerLogo = loadShape("ConnChemLogo.svg");
    button_arrow_small_down_down  = loadShape("gui/button-arrow-small-down-down.svg");
    button_arrow_small_down_up    = loadShape("gui/button-arrow-small-down-up.svg");
    button_arrow_small_left_down  = loadShape("gui/button-arrow-small-left-down.svg");
    button_arrow_small_left_up    = loadShape("gui/button-arrow-small-left-up.svg");
    button_arrow_small_right_down = loadShape("gui/button-arrow-small-right-down.svg");
    button_arrow_small_right_up   = loadShape("gui/button-arrow-small-right-up.svg");
    button_arrow_small_up_down    = loadShape("gui/button-arrow-small-up-down.svg");
    button_arrow_small_up_up      = loadShape("gui/button-arrow-small-up-up.svg");
    button_minus_up               = loadShape("gui/button-minus-up.svg");
    button_pause_down             = loadShape("gui/button-pause-down.svg");
    button_pause_up               = loadShape("gui/button-pause-up.svg");
    button_play_down              = loadShape("gui/button-play-down.svg");
    button_play_up                = loadShape("gui/button-play-up.svg");
    button_plus_up                = loadShape("gui/button-plus-up.svg");
    button_reset_down             = loadShape("gui/button-reset-down.svg");
    button_reset_up               = loadShape("gui/button-reset-up.svg");
  }

/*----------------------------------------------------------------------------*/

// mouse
public void mousePressed() {
  
  // molecule controls
  for (int i = 0; i < moleculeControls.length; i++) {
    if (moleculeControls[i].controlState == "over") {
      if (i % 2 == 0) { // even numbers
        int tmp = i;
        if (tmp != 0) {tmp = tmp/2;}
        appendMolecule(moleculeTypes[tmp], random(canvasLeft, canvasRight), random(canvasTop, canvasBottom));
      } else { // odd numbers
        removeMolecule(moleculeTypes[floor(i/2)]);
      }
    }
  }
}

/*----------------------------------------------------------------------------*/

// fonts
  public void setFonts() {    
    fontMyriadProBold22   = loadFont("fonts/MyriadPro-Bold-22.vlw");
    fontMyriadProCond12   = loadFont("fonts/MyriadPro-Cond-12.vlw");
    fontMyriadPro10       = loadFont("fonts/MyriadPro-Regular-10.vlw");
    fontMyriadPro12       = loadFont("fonts/MyriadPro-Regular-12.vlw");
    fontMyriadPro18       = loadFont("fonts/MyriadPro-Regular-18.vlw");
    fontMyriadPro22       = loadFont("fonts/MyriadPro-Regular-22.vlw");
  };
  
/*----------------------------------------------------------------------------*/

// molecule actions
  public void appendMolecule(String moleculeName, float xLoc, float yLoc) {
    countMolecules();
    for (int i = 0; i < moleculeTypes.length; i++) {
      if (moleculeName == moleculeTypes[i]) {
        if (moleculeCount[i] < moleculeQntyMax) {
          molecules[moleculeQntyTotal] = new Molecule(moleculeName, xLoc, yLoc);
        }
      }
    }
    countMolecules();
  }
  
  public void removeMolecule(String moleculeName) {
    countMolecules();
    // locate a relevant molecule in array
    int offset = 0;
    while (molecules[offset] != null && moleculeName != molecules[offset].moleculeName && offset < molecules.length - 1) {
      offset++;
    }
    for (int i = offset; i < molecules.length - 1; i++) {
      molecules[i] = molecules[i+1];
    }
    countMolecules();
  }
  
  public void removeMoleculeByID(int moleculeToKillID) {
    // locate the relevant molecule in the array
    int offset = 0;
    while (molecules[offset].moleculeID != moleculeToKillID) {
      offset++;
    }
    for (int i = offset; i < molecules.length - 1; i++) {
      molecules[i] = molecules[i+1];
    }
    countMolecules();
  }
  
  public void swapMolecules(int oldMoleculeID1, int oldMoleculeID2, String newMoleculeName1, String newMoleculeName2, String newMoleculeName3) {
    countMolecules();
    PVector oldLoc = new PVector(0, 0);
    countMolecules();
  }

// iterate and tabulate totals of all types of atoms
  public void countMolecules() {
    // clear existing count
    for (int i = 0; i < moleculeCount.length; i++) {
      moleculeCount[i] = 0;
    }
    int i = 0;
    while (molecules[i] != null) {
      String mName = molecules[i].moleculeName;
      for (int ii = 0; ii < moleculeTypes.length; ii++) {
        if (mName == moleculeTypes[ii]) {
          moleculeCount[ii]++;
        }
      }
      i++;
    }
    moleculeQntyTotal = i;
  }
  
  public int getHighestID() {
    int molID = 0;
    for (int i = 0; i < moleculeQntyTotal; i++) {
      if (molecules[i].moleculeID > molID) {
        molID = molecules[i].moleculeID;
      }
    }
    return molID;
  }
  
  // count, for the past n seconds (in this case "secondsCounted"), the number of molecules, of each type, per second
  public void setMoleculeQntyPast() {
    if (currentSecond > previousSecond) {
      for (int i = 0; i < moleculeTypes.length; i++) {
        for (int j = secondsCounted-1; j > 0; j--) {
          moleculeCountPast[i][j] = moleculeCountPast[i][j-1];
        }
        moleculeCountPast[i][0] = moleculeCount[i];
      }
    }
  };
  
/*----------------------------------------------------------------------------*/
  
// colors
  public void setColors() {};
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "alpha3" });
  }
}
