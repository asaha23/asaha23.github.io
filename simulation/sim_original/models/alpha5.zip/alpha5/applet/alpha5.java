import processing.core.*; 
import processing.xml.*; 

import controlP5.*; 
import geomerative.*; 
import prohtml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class alpha5 extends PApplet {

// Connected Chemistry Curriculum
// Project Leader: Mike Stieff, PhD, University of Illinois at Chicago
// Modeled in Processing by: Allan Berry
/*--------------------------------------------------------------------------*/

// imports
    
    
    
  
// variables
    String      headerTitle;
    String      headerSubtitle;
    PShape      headerLogo;

  // units and dimensions
    float       mod;      // setup a standard module size for graphics
    int         iMod;     // same as above, but as integer
  // main window
    int         globalW;  // window width
    int         globalH;  // window height

  // global locative variables; used by ControlP5
    public float controlScale;
    float       controlScaleMin;
    float       controlScaleDef;
    float       controlScaleMax;
  
  // global time variables
    float       globalFrameRate;
    float       globalSpeed;
    float       globalSpeedBeforePause; // used for pausing, to remember previous speed
    
  // controlP5 variables
    public float  controlSpeed;
    float         controlSpeedMin;
    float         controlSpeedDef;
    float         controlSpeedMax;
    
  // time display variables
    
  // time units (tU's)
    float       tU;  // one tU, a duration of time in milliseconds
    int         previousTU;
    int         currentTU;
    int         previousSecond;
    int         currentSecond;
    int         previousMinute;
    int         currentMinute;
    
    int         elapsedMillis;  // replacement for millis(); allows sketch to be started and stopped.
    int         prevMillis = 0;     // when the simulation is restarted, this will store the time of restart, then total time of subsequent restarts
    Boolean     paused;
    
    int         pauseBegin;
    int         pauseEnd;
    int         lastPauseDuration;
    int         pauseTotal;  // cumulative amount of time the current run of the simulation has been paused
    
    int         playBegin;
    int         playEnd;
    int         lastPlayDuration;
    int         playTotal;  // cumulative amount of time the current run of the simulation has been played
  
  // fonts
    PFont       fontMyriadProBold22;
    PFont       fontMyriadProBold12;
    PFont       fontMyriadProCond12;
    PFont       fontMyriadPro10;
    PFont       fontMyriadPro12;
    PFont       fontMyriadPro18;
    PFont       fontMyriadPro22;
    
  // data
    Table       elementTable; // main repository for element data
    int         elementTableRowCount;
    int[]       elementNumber;
    String[]    elementName;
    String[]    elementSymbol;
    String[]    elementColorName;
    int[]       elementColorRed;
    int[]       elementColorGreen;
    int[]       elementColorBlue;
    //elementNameWaalsRadius;
    float[]     elementAtomicRadius;
    float[]     elementAtomicMass;
    
  // main molecule container
  
    public int unit;
    String unitName;
    int lesson;
    String lessonName;
    int activity;
    String activityName;

    Table speciesTable;
    String[] species;
    int[] speciesStartQnty;
  
    Molecule[]  molecules;
    int[]       moleculeCount;
    
    // counts over time
    ArrayList   moleculeRoll; // molecule counts over time
    //ArrayList   pHRoll;       // pH counts over time
    int         countsPerSecond; // the number of times molecule quantities are recorded per second
    
  // new reaction table
    Table       reactTable;
    int         reactTableRowCount;
    String[]    reactants;
    float[]     reactProbabilities;
    String[]    reactResults;
    
    ArrayList   reactInputs;
    float       reactProbability;
    ArrayList   reactOutputs;
    
  // GUI
    ControlP5   controlP5;  // GUI plot controller
    Slider      sliderScale;
    Slider      sliderSpeed;
    GPlot[]     plots;
    GButton[]   moleculeButtons;
    // time buttons
    GButton     playPauseButton;
    GButton     resetButton;
    
    PShape      button_arrow_small_down_down;
    PShape      button_arrow_small_down_up;
    PShape      button_arrow_small_left_down;
    PShape      button_arrow_small_left_up;
    PShape      button_arrow_small_right_down;
    PShape      button_arrow_small_right_up;
    PShape      button_arrow_small_up_down;
    PShape      button_arrow_small_up_up;
    PShape      button_minus_up;
    PShape      button_pause_down;
    PShape      button_pause_up;
    PShape      button_play_down;
    PShape      button_play_up;
    PShape      button_plus_up;
    PShape      button_reset_down;
    PShape      button_reset_up;

  // Grid
  // column 1
    float       gridCol1X;
    float       gridCol1W;
  // column 2
    float       gridCol2X;
    float       gridCol2W;
  // row 1
    float       gridRow1Y;
    float       gridRow1H;
  // row 2
    float       gridRow2Y;
    float       gridRow2H;
  // row 3
    float       gridRow3Y;
    float       gridRow3H;
  // canvas
    float       canvasTop;
    float       canvasRight;
    float       canvasBottom;
    float       canvasLeft;
  
  // molecule quantity defaults; used by molecule tracking plot & ControlP5
    int         moleculeQntyMin;
    int         moleculeQntyDef;
    int         moleculeQntyMax;
    int         moleculeQntyTotal;
    
  // colors
    int       cFill_Bg;
    int       cFill_Canvas;
    int       cFill_Plot;
    int       cStrk_Plot;
    int       cStrk_Default;
    int       cFill_Atom;
    int       cStrk_Atom;
    int       cText;

    int[]     cPlot;

public void setup() {
  // bootstrap
    prevMillis = prevMillis - millis();  // this should only happen ONCE.  therefore, setup() is not meant for multiple use.
    setSpecies();
    
    setDefaultVars();
    setElementTable();
    setReactionTable();
    
    globalW = iMod * 18;    // main window width
    globalH = iMod * 14;    // main window height
    size(864, 672);
    
    frameRate(globalFrameRate);
    smooth();
    
  // set main systems
    
  // initialize molecule container
    initMolecules();
    
    initTimeSpace();
  
  // set gui  
    setFonts();
    setSVGs();
    setPlots();
    setTimeButtons();
    setMoleculeButtons();
    setColours();
    setGeomerative("init");
    setControlP5("init");
    
    countMolecules();
};
  
public void draw() {
  updateTime();
  drawBg();
  drawCanvasBg();
  
  // column 2
  for (int i = 0; i < moleculeQntyTotal ; i++) {
    molecules[i].update();
    molecules[i].display();
  }
  
  // column 1 (occludes molecules when they overlap column 2)
  drawCol1Bg();
  drawHeaderText();
  
  // controls
  playPauseButton.update();
  resetButton.update();
  playPauseButton.display();
  resetButton.display();
  
  for (int i = 0; i < moleculeButtons.length; i++) {
    moleculeButtons[i].update();
    moleculeButtons[i].display();
  };
  // plots
  for (int i = 0; i < plots.length; i++) {
    plots[i].update();
    plots[i].display();
  };
  
  setControlP5("label");
  
  setControlText();  // this will need to be integrated in the plot class... too busy now
};
public class GButton {
  // variables
  int     buttonID;
  String  buttonType = "default";
  String  buttonState = "up";
  
  // locative variables
  float   buttonX;
  float   buttonY;
  float   buttonW;
  float   buttonH;
  
  // display variables
  boolean buttonFill = true; // widget has background
  boolean buttonStrk = true; // widget has outline
  
  // label variables
  String  labelText;
  float   labelX;
  float   labelY;
  
  PShape buttonIcon;  
  
  int cFillMainUp       = color(127, 127, 127);
  int cFillMainOver     = color(157, 157, 157);
  int cFillMainActive   = color(234, 91, 12);
  int cFillMainDown     = color(176, 69, 23);
  int cFillMain         = cFillMainUp;
  
  int cStrkMainUp       = color(100, 100, 100);
  int cStrkMainOver     = color(178, 178, 178);
  int cStrkMainActive   = color(204, 69, 23);
  int cStrkMainDown     = color(154, 52, 21);
  int cStrkMain         = cStrkMainUp;
  
  int cFillHandleUp     = color(51, 94, 127);
  int cFillHandleOver   = color(51, 94, 190);
  int cFillHandleActive = color(81, 186, 230);
  int cFillHandleDown   = color(38, 169, 224);
  int cFillHandle       = cFillHandleUp;
  
  int cStrkHandleUp     = color(43, 56, 143);
  int cStrkHandleOver   = color(43, 56, 189);
  int cStrkHandleActive = color(73, 145, 201);
  int cStrkHandleDown   = color(27, 117, 187);
  int cStrkHandle       = cStrkHandleUp;
  
  int cFillDim          = color(127);
  int cStrkDim          = color(110);
  int cTextDim          = color(166);
  
  int cTextLabel        = color(255);
  int cStrkShadow       = color(90, 127);
  int cStrkHilite       = color(255, 25);
  
  // constructor
  public GButton(float buttonX_, float buttonY_, float buttonW_, float buttonH_) {
    buttonX = buttonX_;
    buttonY = buttonY_;
    buttonW = buttonW_;
    buttonH = buttonH_;
    init();
  }
  
  // methods
  public void init() {
    if (buttonType.equals("add molecule") || buttonType.equals("remove molecule")) {
      labelX = buttonX + mod/4;    
      labelY = buttonY + mod/3;
    }
  }
  
  public void update() {
    
    detectMouseOver();
    setButtonColors();
    setOverrides();
    if (buttonType.equals("add molecule")) {
      buttonIcon = button_plus_up;
    }
    if (buttonType.equals("remove molecule")) {
      buttonIcon = button_minus_up;
    }
    if (buttonType.equals("play")) {
      buttonIcon = button_play_up;
    }
    if (buttonType.equals("pause")) {
      buttonIcon = button_pause_up;
    }
    if (buttonType.equals("reset")) {
      buttonIcon = button_reset_up;
    }
  }

  public void display() {
    pushStyle();
      fill(cFillMain);
      stroke(cStrkMain);
      rect(buttonX, buttonY, buttonW, buttonH);
      shapeMode(CENTER);
      shape(buttonIcon, buttonX + buttonW/2, buttonY + buttonW/2, mod, mod);
    popStyle();
  }
  
  public void setButtonColors() {
    if (buttonState == "over") {
      cFillMain   = cFillMainOver;
      cStrkMain   = cStrkMainOver;
      cFillHandle = cFillHandleOver;
      cStrkHandle = cStrkHandleOver;
    } else if (buttonState == "active") {
      cFillMain   = cFillMainActive;
      cStrkMain   = cStrkMainActive;
      cFillHandle = cFillHandleActive;
      cStrkHandle = cStrkHandleActive;
    } else if (buttonState == "down") {
      cFillMain   = cFillMainDown;
      cStrkMain   = cStrkMainDown;
      cFillHandle = cFillHandleDown;
      cStrkHandle = cStrkHandleDown;
    } else { /* up */
      cFillMain   = cFillMainUp;
      cStrkMain   = cStrkMainUp;
      cFillHandle = cFillHandleUp;
      cStrkHandle = cStrkHandleUp;
    }
  };
  
  public void setOverrides() {
    if (buttonType == "add molecule") {
      if (buttonState == "over") {
        cFillMain   = color(74, 186, 127);
        cStrkMain   = color(86, 222, 98);
      } else if (buttonState == "active") {
        cFillMain   = color(43, 199, 0);
        cStrkMain   = color(0, 148, 13);
      } else { /* up */
        cFillMain   = color(51, 128, 88);
        cStrkMain   = color(67, 172, 76);
      }
    }    
    if (buttonType == "remove molecule") {
      if (buttonState == "over") {
        cFillMain   = color(201, 52, 68);
        cStrkMain   = color(255, 82, 98);
      } else if (buttonState == "active") {
        cFillMain   = color(255, 0, 22);
        cStrkMain   = color(191, 0, 17);
      } else { /* up */
        cFillMain   = color(128, 51, 59);
        cStrkMain   = color(189, 31, 45);
      }
    }
  }
  
  public void detectMouseOver() {
    if (mouseX > buttonX && mouseX < buttonX + buttonW && mouseY > buttonY && mouseY < buttonY + buttonH) {
      if (mousePressed == true) {
        buttonState = "active";
      } else {
        buttonState = "over";
      }
    } else {
      buttonState = "up";
    }
  }
/*----------------------------------------------------------------------------*/
// labels
  public void drawLabels() {
    pushStyle();
      fill(cTextLabel);
      if (labelText != null) {
          text(labelText, labelX, labelY);
      }
    popStyle();
  };
}
public class GPlot {
  // variables
    int       plotID;
    String    plotType;   // e.g. "molecule", "pH"
    String    controlState = "up";
    
    // locative variables
    float   plotX;
    float   plotY;
    float   plotW;
    float   plotH;
    
    // mouse coordinates
    float   xCoord;
    float   yCoord;
    
    // display variables
    boolean plotFill = true; // plot has background
    boolean plotStrk = true; // plot has outline
    int   fillColor = cFill_Plot;
    int   strokeColor = cStrk_Plot;
    
    // label variables
    int   labelColor;
    float   labelX1;
    float   labelY1;
    float   labelX2;
    float   labelY2;
    
    String  timeElapsedMMSS;
    
    // plot variables
    
    float sectionQnty;    // 
    float sectionDuration;  // number of seconds it takes to cross from left to right of a plot Section
    float sectionDurationTUs;
    float plotDuration;
    float plotDurationTUs;

    float yTicksTotal;

    float sectionW;  // LENGTH measure; defaults to distance covered in a minute
    float xTicksPerSection;
    float xTicksTotal;

    float xTick; 
    float yTick;

    float currentX;
      // also need to check whether any species count exceeds yTicksTotal; if so, increase yTicksTotal
      // yTicksTotal = whatever is greater: 50 or the largest molecule species count

    // every minute
      //plotDiv++;
      
    int currSec;
    int currMin;
    String textCrosshairR = "";
    String textCrosshairB = "";
    
    float labelOffset = mod/6;
    float textLocTY = plotY - mod/2;
    float textLocRX = plotY + plotW + mod/2;
    float textLocBY = plotY + plotH + mod/2;
    float textLocLX = plotX - mod/2;
    
    String textTL = ""; 
    String textTC = ""; 
    String textTR = ""; 
    String textRT = ""; 
    String textRC = ""; 
    String textRB = ""; 
    String textBL = ""; 
    String textBC = ""; 
    String textBR = ""; 
    String textLT = ""; 
    String textLC = ""; 
    String textLB = "";
    
    float rightBoxX;
    float rightBoxW;
    float rightBoxH;
    float rightBoxY;

    float bottomBoxY;
    float bottomBoxW;
    float bottomBoxH;
    float bottomBoxX;

    float yMolQnty;
    float xSeconds;

    String yMolQntyFormatted;
    String xMinutesFormatted;
    String xSecondsFormatted;
    String xFormatted;
    

  // constructor
  public GPlot(String plotType_, float plotX_, float plotY_, float plotW_, float plotH_) {
    plotType = plotType_;
    plotX = plotX_;
    plotY = plotY_;
    plotW = plotW_;
    plotH = plotH_;
    
    init();
  };

  // methods
  public void init() {
    
    textFont(fontMyriadPro10, 10);
    labelColor = color(255, 255, 255);
    sectionQnty = 1;    // 
    sectionDuration = 60;  // number of seconds it takes to cross from left to right of a plot Section
    sectionDurationTUs = sectionDuration * countsPerSecond;
    
    yTicksTotal = 50;
  }
  
  public void update() {
    currSec = currentSecond % 60;
    currMin = currentMinute % 60;

    if (currentMinute > previousMinute) {
      sectionQnty++;
    }
    plotDuration      = sectionQnty * sectionDuration;
    plotDurationTUs   = plotDuration * countsPerSecond;
    sectionW          = plotW / sectionQnty;  // LENGTH measure; defaults to distance covered in a minute
    xTicksPerSection  = sectionDurationTUs;
    xTicksTotal       = sectionQnty * xTicksPerSection;
    xTick             = plotW / xTicksTotal; 
    yTick             = plotH / yTicksTotal;
    currentX          = xTick * currentTU;
    
    getMouseCoordinates();
    detectMouseOver();
    
    rightBoxX = 0;
    rightBoxW = mod*2/3;
    rightBoxH = mod/2;
    rightBoxY = mouseY - plotY - rightBoxH/2;

    bottomBoxY = 0;
    bottomBoxW = mod*2/3;
    bottomBoxH = mod/2;
    bottomBoxX = mouseX - plotX - rightBoxW/2;

    yMolQnty = moleculeQntyMax * yCoord;
    xSeconds = sectionDuration * sectionQnty * xCoord;

    yMolQntyFormatted = str(round(yMolQnty));
    xMinutesFormatted = nf(round(xSeconds) / 60, 2);
    xSecondsFormatted = nf(round(xSeconds) % 60, 2);
    xFormatted = xMinutesFormatted + ":" + xSecondsFormatted;
    
    
    // override default labelling
    if (plotType == "Molecules") {      
      textCrosshairR = yMolQntyFormatted;
      textCrosshairB = xFormatted;
      
      textTL = "Molecule Quantity";
      textTC = "";
      textTR = str(moleculeQntyTotal);
      textRT = "";
      textRC = "";
      textRB = "";
      textBL = "Start";
      textBC = "Time";
      textBR = floor(sectionQnty) + " mins";
      textLT = str(moleculeQntyMax);
      textLC = "# of molecules";
      textLB = str(moleculeQntyMin);
    } /*else if (plotType == "pH") {
      textCrosshairR = nf(14 * yCoord, 0, 1);
      textCrosshairB = xFormatted;
      
      textTL = "pH";
      textTC = "";
      textTR = nf(getPH(), 0, 2);
      textRT = "";
      textRC = "";
      textRB = "";
      textBL = "Start";
      textBC = "Time";
      textBR = floor(sectionQnty) + " mins";
      textLT = str(14);
      textLC = "pH Level";
      textLB = str(0);

    }*/
  }
  
  public void display() {
    drawBackground();
    drawGrid();
    drawPlotLines();
    //drawHead();
    drawStroke(); // stroke and labels should be drawn after visualization
    drawLabels();
    drawCrosshairs();
  }
  
  public void detectMouseOver() {
    if (mouseX > plotX && mouseX < plotX + plotW && mouseY > plotY && mouseY < plotY + plotH) {
      if (mousePressed == true) {
        controlState = "active";
      } else {
        controlState = "over";
      }
    } else {
      controlState = "up";
    }
  }
  
  public void getMouseCoordinates() {
    xCoord = norm(mouseX - plotX, 0, plotW);
    yCoord = norm(mouseY - plotY, plotH, 0);
  }

/*----------------------------------------------------------------------------*/
// box
  public void drawBackground() {
    if (plotFill == true) {      
      pushStyle();
        fill(fillColor);
        noStroke();
        rect(plotX, plotY, plotW, plotH);
      popStyle();
    }
  };
  
  public void drawGrid() {
    pushStyle();
    stroke(85);
    pushMatrix();
    translate(plotX, plotY);
    for (int i = 0; i < sectionQnty; i++) {
      line(xTicksPerSection * xTick * i, 0, xTicksPerSection * xTick * i, plotH);
    }
    /*if (plotType.equals("pH")) {
      //line(0, plotH/2, plotW, plotH/2);
    }*/
    popMatrix();
    popStyle();
  }
  
  public void drawPlotLines() {
    
    // the following variable allows a plot with decreased resolution to only render certain modulo of available data
    int skip = floor(sectionQnty);
    
    pushMatrix();
    translate(plotX, plotY);
    pushStyle();
    
    if (plotType.equals("Molecules")) {
      float xValue = 0;
      float yValue = plotH;
      float[] prevX = new float[species.length];
      float[] prevY = new float[species.length];

      // init previous location array
      for (int i = 0; i < prevX.length; i++) {
        prevX[i] = 0;
        prevY[i] = plotH;
      }

      int[] molCount = new int[species.length];


      for (int i = 1; i < moleculeRoll.size(); i=i+skip) {
        molCount = (int[])moleculeRoll.get(i-1);

        for (int ii = 0; ii < species.length; ii++) {
          stroke(cPlot[ii]);
          strokeWeight(1.5f);

          xValue = i * xTick;
          yValue = plotH - (molCount[ii] * yTick);

          line(xValue, yValue, prevX[ii], prevY[ii]);

          prevX[ii] = xValue;
          prevY[ii] = yValue;
        }
      }
    } /*else if (plotType.equals("pH")) {
      float xValue = 0;
      float yValue = plotH;
      float prevX = 0;
      float prevY = plotH;

      float   pHval;

      for (int i = 1; i < pHRoll.size(); i=i+skip) {
        pHval = (Float)pHRoll.get(i-1);
        stroke(255);
        strokeWeight(1.5);

        xValue = i * xTick;
        yValue = plotH - map(pHval, 0, 14, 0, plotH);

        line(xValue, yValue, prevX, prevY);

        prevX = xValue;
        prevY = yValue;
      }
    }*/
    popStyle();
    popMatrix();
  }
  
  public void drawHead() {
    pushStyle();
    stroke(115);
    pushMatrix();
    translate(plotX, plotY);
      // middle
      line(currentX, 0, currentX, plotH);
    popMatrix();
    popStyle();
  }
  
  public void drawCrosshairs() {
    
    pushStyle();
    stroke(127);
    pushMatrix();
    
    translate(plotX, plotY);
      if (controlState == "over" || controlState == "active" ) {
        // horizontal line
        line(0, mouseY - plotY, plotW, mouseY - plotY);
        // vertical line
        line(mouseX - plotX, 0, mouseX - plotX, plotH);
        
        // labels
        fill(0, 150);
        rightBoxX = 0;
        rightBoxW = mod*2/3;
        rightBoxH = mod/2;
        rightBoxY = mouseY - plotY - rightBoxH/2;
        
        bottomBoxY = 0;
        bottomBoxW = mod*2/3;
        bottomBoxH = mod/2;
        bottomBoxX = mouseX - plotX - rightBoxW/2;
        
        yMolQnty = moleculeQntyMax * yCoord;
        xSeconds = sectionDuration * sectionQnty * xCoord;
        
        yMolQntyFormatted = str(round(yMolQnty));
        xMinutesFormatted = nf(round(xSeconds) / 60, 2);
        xSecondsFormatted = nf(round(xSeconds) % 60, 2);
        xFormatted = xMinutesFormatted + ":" + xSecondsFormatted;
        
        pushMatrix();
        translate(plotW, 0);
          rect(rightBoxX, rightBoxY, rightBoxW, rightBoxH);
          textAlign(CENTER);
          pushStyle();
            fill(labelColor);
            text(textCrosshairR, rightBoxX + rightBoxW/2, rightBoxY + rightBoxH/2 + mod/12);
          popStyle();
        popMatrix();
        
        pushMatrix();
        translate(0, plotH);
          rect(bottomBoxX, bottomBoxY, bottomBoxW, bottomBoxH);
          textAlign(CENTER);
          pushStyle();
            fill(labelColor);
            text(textCrosshairB, bottomBoxX + bottomBoxW/2, bottomBoxY + bottomBoxH/2 + mod/12);
          popStyle();
        popMatrix();
      }
    popMatrix();
    popStyle();
  }
  
  public void drawStroke() {
    if (plotStrk == true) {
      pushStyle();
        noFill();
        /*// frame, to mask a little of line overlap
        stroke(cFill_Bg);
        strokeWeight(3);
        rect(plotX - 2, plotY - 2, plotW + 4, plotH + 4);*/
        stroke(strokeColor);
        strokeWeight(1);
        rect(plotX, plotY, plotW, plotH);
      popStyle();
    }
  }

/*----------------------------------------------------------------------------*/
// labels
  public void drawLabels() {
    pushStyle();
    fill(labelColor);

    // top text
    pushStyle();
      textFont(fontMyriadProBold12, 12);
      textAlign(LEFT);
      text(textTL, plotX, plotY - labelOffset);
    popStyle();
    textAlign(CENTER);
    text(textTC, plotX + plotW/2, plotY - labelOffset);
    textAlign(RIGHT);
    text(textTR, plotX + plotW, plotY - labelOffset);
    
    // right text
    textAlign(LEFT);
    text(textRT, plotX + plotW + labelOffset, plotY + labelOffset);
    pushMatrix();
      textAlign(CENTER);
      translate(plotX + plotW + labelOffset, plotY + plotH/2);
      rotate(PI/2);
      text(textRC, 0, 0);
    popMatrix();
    textAlign(LEFT);
    text(textRB, plotX + plotW + labelOffset, plotY + plotH);
    
    // bottom text
    textAlign(LEFT);
    text(textBL, plotX, plotY + plotH + labelOffset + labelOffset);
    textAlign(CENTER);
    text(textBC, plotX + plotW/2, plotY + plotH + labelOffset + labelOffset);
    textAlign(RIGHT);
    text(textBR, plotX + plotW, plotY + plotH + labelOffset + labelOffset);
    
    // left text
    textAlign(RIGHT);
    text(textLT, plotX - labelOffset, plotY + labelOffset);
    pushMatrix();
      textAlign(CENTER);
      translate(plotX - labelOffset, plotY + plotH/2);
      rotate(PI/2*-1);
      text(textLC, 0, 0);
    popMatrix();
    textAlign(RIGHT);
    text(textLB, plotX - labelOffset, plotY + plotH);
    
    popStyle();
  };
};
public class Molecule {
  
  //after implementation with sin/cos, consult http://wiki.processing.org/w/Sin/Cos_look-up_table
  
  // variables
    int       moleculeID;
    
    // reactions
    int       spouse;  // only gets filled upon molecule reaction; the ID of the molecule it is reacting with
    
    // molecular variables
    String    moleculeName;   // e.g. "Water"
    String    moleculeFormula;   // e.g. "H2O", or rather "H<sub>2</sub>O";
                              // use <sub> for subscript, <sup> for superscript
    
    boolean   moleculePaused = false; // this ensures that a molecule cannot be paused twice, thus erasing valuable saved data

    // locative variables
    PShape    mShape;
    float     mScale = 1;
    PVector   loc;
    PVector   dir;
    PVector   velAdj;
    PVector   vel;
    PVector   acc;
    float     topSpeed;
    float     rotation; // current absolute rotation: default .2 rad, i.e. 1 rotation/second
    float     rotationRate;   // rate of rotation
    float[]   molDist;
    float[]   reactProb;    // list of the raction probability with different molecules
                            // Default: 1.0.  This should probably be converted to a hashmap
    //float pH;     // optional; pH of concentrated compound
    float moleculeRadius = 30;
    float contourRadius;  // dependent on scale
    
    // utility variables
    PVector   emptyPV = new PVector(0, 0);
    
    // variables to store movement data while paused
    PVector   storeVel;
    PVector   storeVelAdj;
    PVector   storeDir;
    PVector   storeAcc;
    float     storeRot;
    float     storeRotRate;
    
  // constructor
  public Molecule(String moleculeName_) {
    moleculeName    = moleculeName_;
    loc = new PVector(random(canvasLeft, canvasRight), random(canvasTop, canvasBottom));
    init();
  }
  
  // constructor
  public Molecule(String moleculeName_, float xLoc_, float yLoc_) {
    moleculeName    = moleculeName_;
    loc = new PVector(xLoc_, yLoc_);
    init();
  }
  
  // methods
    //locative methods
    public void init() {
      try {
        mShape = loadShape("svg/" + moleculeName.replace(" ", "-") + ".svg");
      } catch (Exception e) {
        mShape = loadShape("svg/Generic.svg");
      }
      moleculeID = getHighestID() + 1;
      setContourRadius(moleculeName);
      vel           = new PVector(random(-.5f, .5f), random(-.5f, .5f));
      acc           = new PVector(0,0);
      topSpeed      = 10;
      rotation      = random(0, 2);       // current absolute rotation: default .2 rad, i.e. 1 rotation/second
      rotationRate  = random(.05f, .3f);    // rate of rotation
      /*if (paused == true) {
        pauseMotion();
      }*/
    }
    
    public void update() {
      if (vel.x != 0 && vel.y != 0) {
        dir         = vel.get();
        dir.normalize();
        
        velAdj = dir.get();
        velAdj.mult(controlSpeed);
        vel.add(velAdj);

        vel.add(acc);
        vel.limit(topSpeed * controlSpeed);
        loc.add(vel);
      }
      contourRadius = moleculeRadius * controlScale;
      rotation = rotation + rotationRate * controlSpeed;
      mScale = controlScale;
    }
    
    public void display() {
      pushMatrix();
      translate(loc.x, loc.y);
      rotate(rotation);
        shape(mShape, mShape.width * mScale/-2, mShape.height * mScale/-2, mShape.width * mScale, mShape.height * mScale);
       /*pushStyle(); // this shows contour circle  // this stuff will draw a radius for debugging
          noFill();
          stroke(255);
          ellipse(0, 0, contourRadius*2, contourRadius*2);
        popStyle();*/
      popMatrix();
      
      if (paused == true) {
        pauseMotion();
      } else {
        unpauseMotion();
        wallBounce();
        reaction();
      }
    }
    
    public void setContourRadius(String moleculeName) {
           if (moleculeName == "Water") {moleculeRadius = 30;}
      else if (moleculeName == "Acetic Acid") {moleculeRadius = 60;}
      else if (moleculeName == "Bromide") {moleculeRadius = 25;}
      else if (moleculeName == "Hydrogen Chloride") {moleculeRadius = 30;}
      else if (moleculeName == "Sodium Acetate") {moleculeRadius = 60;}
      else if (moleculeName == "Sodium Chloride") {moleculeRadius = 60;}
      else if (moleculeName == "Sodium Hydroxide") {moleculeRadius = 60;}
         else {moleculeRadius = 30;}
    }

    public void pauseMotion() {
      // variables to store movement data while paused
      if (moleculePaused == false) {
        storeVel      = vel.get();
        storeVelAdj   = velAdj.get();
        storeDir      = dir.get();
        storeAcc      = acc.get();
        storeRotRate  = rotationRate;
        
        vel           = emptyPV.get();
        velAdj   = emptyPV.get();
        dir           = emptyPV.get();
        acc           = emptyPV.get();
        rotationRate  = 0;
      }
      moleculePaused  = true;
    }

    public void unpauseMotion() {
      if (moleculePaused == true) {
        vel           = storeVel.get();
        velAdj   = storeVelAdj.get();
        dir           = storeDir.get();
        acc           = storeAcc.get();
        rotationRate  = storeRotRate;
      }
      moleculePaused  = false;
    }
    
    public void wallBounce() {
      // bounce into canvas edges
      if (loc.x - contourRadius < canvasLeft) {
        revDirX();
        revRotation();
        while (loc.x - contourRadius < canvasLeft) {
          loc.x = loc.x + .1f;
        }
      };
      if (loc.x + contourRadius > canvasRight) {
        revDirX();
        revRotation();
        while(loc.x + contourRadius > canvasRight) {
          loc.x = loc.x - .1f;
        }
      };
      if (loc.y - contourRadius < canvasTop) {
        revDirY();
        revRotation();
        while(loc.y - contourRadius < canvasTop) {
          loc.y = loc.y + .1f;
        }
      };
      if (loc.y + contourRadius > canvasBottom) {
        revDirY();
        revRotation();
        while(loc.y + contourRadius > canvasBottom) {
          loc.y = loc.y - .1f;
        }
      };
    };
    
    public void revDirY()      { vel.y = vel.y * -1; }
    public void revDirX()      { vel.x = vel.x * -1; }
    public void revRotation()  { rotationRate = rotationRate * -1; }
    public void setRotation()  { rotation = rotation + rotationRate; }
    
    public void bounce(Molecule otherMolecule) {
      otherMolecule.unpauseMotion();
      PVector velTmp = new PVector(vel.x, vel.y);
      float rotTmp = rotationRate;
      vel = otherMolecule.vel.get();
      rotationRate = otherMolecule.rotationRate;
      otherMolecule.rotationRate = rotTmp;
      otherMolecule.vel = velTmp.get();
      PVector interMolDir = PVector.sub(loc, otherMolecule.loc);
      if (interMolDir.x > 0) {
        loc.x = loc.x + .25f;
      }
      if (interMolDir.x < 0) {
        loc.x = loc.x - .25f;
      }
      if (interMolDir.y > 0) {
        loc.y = loc.y + .25f;
      }
      if (interMolDir.y < 0) {
        loc.y = loc.y - .25f;
      }
    }
    
    public void reaction() {
      for (int i = 0; i < moleculeQntyTotal; i++) {
        float distance = loc.dist(molecules[i].loc);
        // check to see how close together
        if (distance < contourRadius + molecules[i].contourRadius && molecules[i].moleculeID != moleculeID) {
          // check to see if suitable mate; this works for two molecules.  If more than two molecules need to react, this will need to change.
          // if change, the subfunctions should be ok.
          ArrayList mateList = new ArrayList();
          mateList.add(moleculeName);
          mateList.add(molecules[i].moleculeName);
          int reactionNumber = getReactionNumber(mateList);
          float diceRoll = random(1);
          // are both self and object molecule single?  also, check to see if self can mate with other molecule
          if (spouse == 0 && molecules[i].spouse == 0 && reactionNumber >= 0 && diceRoll < reactProbabilities[reactionNumber]) {
            try {
              removeMoleculeByID(molecules[i].moleculeID);
            } catch (Exception e) {
              println("other");
            }
            try {
              removeMoleculeByID(moleculeID);
            } catch (Exception e) {
              println("self");
            }
            String[] arrayResults = reactResults[reactionNumber].split(", ");
            for (int j = 0; j < arrayResults.length; j++) {
              appendMolecule(arrayResults[j], loc.x, loc.y);
            }
          } else { 
            bounce(molecules[i]);
          }
        }
      }
    }
}
// This code from the Processing Table class.  Has not been altered.

class Table {
  int rowCount;
  String[][] data;


  Table(String filename) {
    String[] rows = loadStrings(filename);
    data = new String[rows.length][];

    for (int i = 0; i < rows.length; i++) {
      if (trim(rows[i]).length() == 0) {
        continue; // skip empty rows
      }
      if (rows[i].startsWith("#")) {
        continue;  // skip comment lines
      }

      // split the row on the tabs
      String[] pieces = split(rows[i], TAB);
      // copy to the table array
      data[rowCount] = pieces;
      rowCount++;

      // this could be done in one fell swoop via:
      //data[rowCount++] = split(rows[i], TAB);
    }
    // resize the 'data' array as necessary
    data = (String[][]) subset(data, 0, rowCount);
  }


  public int getRowCount() {
    return rowCount;
  }


  // find a row by its name, returns -1 if no row found
  public int getRowIndex(String name) {
    for (int i = 0; i < rowCount; i++) {
      if (data[i][0].equals(name)) {
        return i;
      }
    }
    println("No row named '" + name + "' was found");
    return -1;
  }


  public String getRowName(int row) {
    return getString(row, 0);
  }


  public String getString(int rowIndex, int column) {
    return data[rowIndex][column];
  }


  public String getString(String rowName, int column) {
    return getString(getRowIndex(rowName), column);
  }


  public int getInt(String rowName, int column) {
    return parseInt(getString(rowName, column));
  }


  public int getInt(int rowIndex, int column) {
    return parseInt(getString(rowIndex, column));
  }


  public float getFloat(String rowName, int column) {
    return parseFloat(getString(rowName, column));
  }


  public float getFloat(int rowIndex, int column) {
    return parseFloat(getString(rowIndex, column));
  }


  public void setRowName(int row, String what) {
    data[row][0] = what;
  }


  public void setString(int rowIndex, int column, String what) {
    data[rowIndex][column] = what;
  }


  public void setString(String rowName, int column, String what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = what;
  }


  public void setInt(int rowIndex, int column, int what) {
    data[rowIndex][column] = str(what);
  }


  public void setInt(String rowName, int column, int what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = str(what);
  }


  public void setFloat(int rowIndex, int column, float what) {
    data[rowIndex][column] = str(what);
  }


  public void setFloat(String rowName, int column, float what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = str(what);
  }  
}


// default variable and immediate derivative input
public void setDefaultVars() {
  paused = true;
  
  // units and dimensions
  mod             = 48;           // setup a standard module size for graphics
  iMod            = floor(mod);   // same as above, but as integer
  globalW         = iMod * 18;    // main window width
  globalH         = iMod * 14;    // main window height
  globalFrameRate = 30;
  countsPerSecond = 4;            // number of times a second molecule quantities are recorded for plots.  Inverse is "timeUnit", e.g. 1/4 second
  tU /*timeUnit*/ = 1/countsPerSecond;

  // GUI
  // Grid
  // column 1
    gridCol1X     = 0;
    gridCol1W     = mod * 6;
  // column 2
    gridCol2X     = gridCol1W;
    gridCol2W     = globalW - gridCol1W;
  // row 1
    gridRow1Y     = 0;
    gridRow1H     = mod * 13;
  // row 2
    gridRow2Y     = gridRow1H;
    gridRow2H     = globalH - gridRow1H;
  // canvas
    canvasTop     = 0;
    canvasRight   = globalW;
    canvasBottom  = globalH - gridRow2H;
    canvasLeft    = gridCol2X;

  // global locative variables
    controlScaleMin    = .05f;
    controlScaleDef    = .5f;
    controlScaleMax    = 1;

  // global time variables
    globalFrameRate   = 30;
    controlSpeedMin    = 0;
    controlSpeedDef    = .25f;
    controlSpeedMax    = .5f;

  // fontscontrolP5Font

  // molecule quantity defaults; used by molecule tracking plot & ControlP5
    moleculeQntyMin   = 0;
    moleculeQntyDef   = 5;
    moleculeQntyMax   = 50;
  
  // colors
    cFill_Bg          = color(150);
    cFill_Canvas      = color(127);
    cFill_Plot        = color(100);
    cStrk_Plot        = color(193);
    cStrk_Default     = color(0);
    cFill_Atom        = color(255);
    cStrk_Atom        = color(0);
    cText             = color(255);
};
/*----------------------------------------------------------------------------*/
// settings
public void setSpecies() {
  // 0 values indicate defaults
  
  if (online) {
    try {
      unit = PApplet.parseInt(param("unitSelect"));
    } catch (Exception e) {
      unit = 0;
    }
    try {
      lesson = PApplet.parseInt(param("lessonSelect"));
    } catch (Exception e) {
      lesson = 0;
    }
    try {
      activity = PApplet.parseInt(param("activitySelect"));
    } catch (Exception e) {
      activity = 0;
    }
  } else {
    unit = 0;
    lesson = 0;
    activity = 0;
  }
  
  try {
    speciesTable = new Table("data/settings/species_" + nf(unit, 2) + "-" + nf(lesson, 2) + "-" + nf(activity, 2) + ".tsv");
  } catch (Exception e) {
    speciesTable = new Table("data/settings/species_00-00-00.tsv");
  }
  
  int speciesTableRowCount = speciesTable.getRowCount();
  
  species   = new String[speciesTableRowCount];
  speciesStartQnty  = new int[speciesTableRowCount];
  
  for (int row = 0; row < speciesTableRowCount; row++) {
    // natural lists
    species[row]  = speciesTable.getString(row, 0);
    speciesStartQnty[row] = speciesTable.getInt(row, 1);
  }  
}

// space and time
  public void initTimeSpace() {
    playBegin = 0;
    playEnd = 0;
    lastPlayDuration = 0;
    playTotal = 0;
    
    pauseBegin = 0;
    pauseEnd = 0;
    lastPauseDuration = 0;
    pauseTotal = 0;
    
    if (paused == true) {
      stopTimer();
    }
    
    currentTU = 0; // init variable, to substitute for null
    currentSecond = 0;
    currentMinute = 0;
    previousTU = 0;
    previousSecond = 0;
    previousMinute = 0;
    
    controlSpeed = controlSpeedDef;
    controlScale = controlScaleDef;
  }
  
  public void updateTime() {    
    if (paused == true) {
      pauseTotal = millis() - playTotal;
    } else {
      playTotal = millis() - pauseTotal;
    }
    
    previousTU = currentTU;
    currentTU = floor(getMillis()/(1000/countsPerSecond));
    
    previousSecond = currentSecond;
    currentSecond = floor(getMillis()/1000);
    
    previousMinute = currentMinute;
    currentMinute = floor(getMillis()/(1000*60));
    
    
    if (currentTU > previousTU) { fireEveryTU(); }
    if (currentSecond > previousSecond) { fireEverySecond(); }
    if (currentMinute > previousMinute) { fireEveryMinute(); }
  }
  
  public void fireEveryTU() {
    if (paused == false) {
      moleculeRoll.add(moleculeCount.clone());
      //pHRoll.add(getPH());
    }
  }
  public void fireEverySecond() {}
  public void fireEveryMinute() {}

  
  //elapsedMillis
  
  public int getMillis() {
    return playTotal;
    //return playTotal;
  }
  
  public void startTimer() {
    println("Timer has STARTED");
    paused = false;
    playBegin = millis();
    pauseEnd = playBegin;
    lastPauseDuration = pauseEnd - pauseBegin;
    //pauseTotal = pauseTotal + lastPauseDuration;
    //printTimes();
  }

  public void stopTimer() {
    println("Timer has STOPPED");
    paused = true;
    pauseBegin = millis();
    playEnd = pauseBegin;
    lastPlayDuration = playEnd - playBegin;
    //playTotal = playTotal + lastPlayDuration;
    //printTimes();
  }

  public void resetSimulation() {
    println("Timer has been RESET");
    setup();
  }
  
/*----------------------------------------------------------------------------*/

// data
  public void setElementTable() {
    elementTable = new Table("data/elements.tsv");
    elementTableRowCount = elementTable.getRowCount();
    
    elementNumber       = new int[elementTableRowCount];
    elementName         = new String[elementTableRowCount];
    elementSymbol       = new String[elementTableRowCount];
    elementColorName    = new String[elementTableRowCount];
    elementColorRed     = new int[elementTableRowCount];
    elementColorGreen   = new int[elementTableRowCount];
    elementColorBlue    = new int[elementTableRowCount];
    //elementNameWaalsRadius;
    elementAtomicRadius = new float[elementTableRowCount];
    elementAtomicMass   = new float[elementTableRowCount];
    
    for (int row = 0; row < elementTableRowCount; row++) {
      // natural lists
      elementNumber[row]        = elementTable.getInt(row, 0);     // column 1
      elementName[row]          = elementTable.getString(row, 1);     // column 2
      elementSymbol[row]        = elementTable.getString(row, 2);     // column 3
      elementColorName[row]     = elementTable.getString(row, 3);     // column 4
      elementColorRed[row]      = elementTable.getInt(row, 4);     // column 5
      elementColorGreen[row]    = elementTable.getInt(row, 5);     // column 6
      elementColorBlue[row]     = elementTable.getInt(row, 6);     // column 7
      //elementNameWaalsRadius[row] = elementTable.getString(row, 7);     // column 8
      elementAtomicRadius[row]  = elementTable.getFloat(row, 8);     // column 9
      elementAtomicMass[row]    = elementTable.getFloat(row, 9);     // column 10
    };
  }
  
  public void setReactionTable() {
    
    reactTable                = new Table("data/reactions2.tsv");
    reactTableRowCount        = reactTable.getRowCount();
    reactants                 = new String[reactTableRowCount];
    reactProbabilities        = new float[reactTableRowCount];
    reactResults              = new String[reactTableRowCount];
    
    for (int row = 0; row < reactTableRowCount; row++) {
      reactants[row]          = reactTable.getString(row, 0);
      reactProbabilities[row] = reactTable.getFloat(row, 1);
      reactResults[row]       = reactTable.getString(row, 2);
    }
  }

/*----------------------------------------------------------------------------*/

// control P5
  public void setControlP5(String action) {
    pushStyle();
    if (action.equals("init")) {
      controlP5     = new ControlP5(this);  // GUI plot controller
    }
      // position and other variables
      int tmpX = iMod*8;
      int tmpY = globalH - PApplet.parseInt(mod*.75f);
      int tmpW = iMod*4;
      int tmpH = iMod/2;
      textFont(fontMyriadPro12);
      fill(cText);
      
    // global scale slider
    if (action.equals("init")) {
    sliderScale = controlP5.addSlider("controlScale", controlScaleMin,  controlScaleMax,  controlScaleDef,  tmpX + iMod/4 - iMod/2, tmpY, tmpW, tmpH);
      sliderScale.captionLabel().set(""); // override controlP5 labels BECAUSE THEY DON'T FUCKING WORK
    } else if (action.equals("label")) {
      textAlign(RIGHT);
      text("Graphic Size", tmpX - iMod/2, globalH - mod/3);
    }
    
    // global speed slider
    if (action.equals("init")) {
    sliderSpeed = controlP5.addSlider("controlSpeed", controlSpeedMin,  controlSpeedMax,  controlSpeedDef,  tmpX + iMod*6 + iMod/4 - iMod/2, tmpY, tmpW, tmpH);
      sliderSpeed.captionLabel().set(""); // override controlP5 labels BECAUSE THEY DON'T FUCKING WORK
    } else if (action.equals("label")) {
      textAlign(RIGHT);
      text("Global Speed", tmpX + iMod*6 - iMod/2, globalH - mod/3);
    }
    popStyle();
  }

/*----------------------------------------------------------------------------*/

// Geomerative
  public void setGeomerative(String action) {
    if (action.equals("init")) {
      RG.init(this);
    }
  }

/*----------------------------------------------------------------------------*/


// native gui elements
  
  public void setTimeButtons() {
    float tGroupX = mod/2;
    float tGroupY = mod*1.5f;
    float tMargin = mod/8;
    
    float playPauseButtonX = tGroupX;
    float playPauseButtonY = tGroupY;
    float playPauseButtonW = mod;
    float playPauseButtonH = mod;
    
    float resetButtonX = playPauseButtonX + playPauseButtonW + mod/4;
    float resetButtonY = tGroupY;
    float resetButtonW = mod;
    float resetButtonH = mod;
    
    playPauseButton = new GButton(playPauseButtonX, playPauseButtonY, playPauseButtonW, playPauseButtonH);
    resetButton = new GButton(resetButtonX, resetButtonY, resetButtonW, resetButtonH);
    
    playPauseButton.buttonType = "play";
    resetButton.buttonType = "reset";
  }
  
  public void setMoleculeButtons() {
    moleculeButtons = new GButton[species.length * 2];
    
    float mGroupX = mod*4;
    float mGroupY = mod*3;
    float mMargin = mod/8;
    
    float bX;
    float bY = mGroupY;
    float bW = mod*.5f;
    float bH = mod*.5f;

    // individual buttons
    for (int i = 0; i < moleculeButtons.length; i++) {
      bX = mGroupX; // resets each iteration
      
      // columns (add or remove): provide X values
      if (i % 2 == 0)
        {} // "add" buttons; no change
      else
        {bX = mGroupX + bW + mMargin;} // "remove" buttons
        
      // rows (by molecule name): provide Y values
      if (i % 2 == 0 && i > 0)
        {bY = bY + bH + mMargin;}
        
      moleculeButtons[i] = new GButton(bX, bY, bW, bH);
      if (i % 2 == 0) {
        moleculeButtons[i].buttonType = "add molecule";
      } else {
        moleculeButtons[i].buttonType = "remove molecule";
      }
    }
  };
  
  public void setControlText() {
    pushStyle();
        textAlign(LEFT);
        textFont(fontMyriadPro12);
        float yPos = mod * 3.5f;
        float yPosOffset = mod * .6f;
        
        for (int i = 0; i < species.length; i++) {
          fill(color(255));
          text(species[i] + "   " + str(moleculeCount[i]), mod, yPos + yPosOffset*i);
          fill(cPlot[i]);
          rect(mod - mod/2,  yPos + yPosOffset*i - mod/4, mod/4, mod/4);
        }
    popStyle();
  }
  
  public void setPlots() {
    plots = new GPlot[1];
    // molecule quantity plot
    //plots[0] = new GPlot("pH",        mod*.75, globalH - mod*7, mod*5, mod*2);
    plots[0] = new GPlot("Molecules", mod*.75f, globalH - mod*4, mod*5, mod*3);
  };
  
  public void setColours() {
    cPlot = new int[12];
    cPlot[0] = color(255, 204, 51, 200);
    cPlot[1] = color(255, 126, 0, 200);
    cPlot[2] = color(255, 0, 0, 200);
    cPlot[3] = color(0, 153, 102, 200);
    cPlot[4] = color(0, 102, 204, 200);
    cPlot[5] = color(0, 0, 255, 200);
    cPlot[6] = color(97, 0, 98, 200);
    cPlot[7] = color(153, 51, 0, 200);
    cPlot[8] = color(255, 108, 182, 200);
    cPlot[9] = color(148, 61, 255, 200);
    cPlot[10] = color(0, 204, 255, 200);
    cPlot[11] = color(51, 255, 51, 200);
  };

  public void drawBg() {
    pushStyle();
      fill(cFill_Bg);
      rect(0, 0, globalW, globalH);
    popStyle();
  }
  public void drawCanvasBg() {
    pushStyle();
      fill(cFill_Canvas);
      rect(canvasLeft, canvasTop, canvasRight, canvasBottom);
    popStyle();
  }
  public void drawCol1Bg() {
    pushStyle();
      fill(cFill_Bg);
      rect(0, 0, gridCol1W, globalH);
    popStyle();
  }
  public void drawHeaderText() {
    String titleUnit = "Unit " + unit + ": Acids & Bases";
    String titleLesson = "Lesson " + lesson;
    String titleActivity = "Activity " + activity;

    headerTitle = "Connected Chemistry";
    headerSubtitle = titleUnit + ", " + titleLesson + ", " + titleActivity;
    
    pushStyle();
    fill(cText);
      textFont(fontMyriadProBold22);
      text(headerTitle, mod/4, mod/2);
      
      textFont(fontMyriadPro12);
      text(headerSubtitle, mod/4, mod);
    popStyle();
    pushMatrix();
    translate(mod*5, mod/2);
      shape(headerLogo, headerLogo.width * -.5f, headerLogo.height * -.5f, headerLogo.width, headerLogo.height);
    popMatrix();
  }
  public void popupContextMenu() {};
  
  public void setSVGs() {
    headerLogo = loadShape("ConnChemLogo.svg");
    button_arrow_small_down_down  = loadShape("gui/button-arrow-small-down-down.svg");
    button_arrow_small_down_up    = loadShape("gui/button-arrow-small-down-up.svg");
    button_arrow_small_left_down  = loadShape("gui/button-arrow-small-left-down.svg");
    button_arrow_small_left_up    = loadShape("gui/button-arrow-small-left-up.svg");
    button_arrow_small_right_down = loadShape("gui/button-arrow-small-right-down.svg");
    button_arrow_small_right_up   = loadShape("gui/button-arrow-small-right-up.svg");
    button_arrow_small_up_down    = loadShape("gui/button-arrow-small-up-down.svg");
    button_arrow_small_up_up      = loadShape("gui/button-arrow-small-up-up.svg");
    button_minus_up               = loadShape("gui/button-minus-up.svg");
    button_pause_down             = loadShape("gui/button-pause-down.svg");
    button_pause_up               = loadShape("gui/button-pause-up.svg");
    button_play_down              = loadShape("gui/button-play-down.svg");
    button_play_up                = loadShape("gui/button-play-up.svg");
    button_plus_up                = loadShape("gui/button-plus-up.svg");
    button_reset_down             = loadShape("gui/button-reset-down.svg");
    button_reset_up               = loadShape("gui/button-reset-up.svg");
  }

/*----------------------------------------------------------------------------*/

// mouse
public void mouseReleased() {
  // molecule buttons
  for (int i = 0; i < moleculeButtons.length; i++) {
    if (moleculeButtons[i].buttonState.equals("active")) {
      if (i % 2 == 0) { // even numbers
        int tmp = i;
        if (tmp != 0) {tmp = tmp/2;}
        appendMolecule(species[tmp]);
      } else { // odd numbers
        removeMolecule(species[floor(i/2)]);
      }
    }
  }
  // time buttons
  if (playPauseButton.buttonState.equals("active")) {
    togglePlayPause();
  }  // time buttons
  if (resetButton.buttonState.equals("active")) {
    resetSimulation();
  }
}

public void togglePlayPause() {
  if (playPauseButton.buttonType.equals("play")) {
    playPauseButton.buttonType = "pause";
    startTimer();
  } else {
    playPauseButton.buttonType = "play";
    stopTimer();
  }
}

/*----------------------------------------------------------------------------*/

// fonts
  public void setFonts() {    
    fontMyriadProBold22   = loadFont("fonts/MyriadPro-Bold-22.vlw");
    fontMyriadProBold12   = loadFont("fonts/MyriadPro-Bold-12.vlw");
    fontMyriadProCond12   = loadFont("fonts/MyriadPro-Cond-12.vlw");
    fontMyriadPro10       = loadFont("fonts/MyriadPro-Regular-10.vlw");
    fontMyriadPro12       = loadFont("fonts/MyriadPro-Regular-12.vlw");
    fontMyriadPro18       = loadFont("fonts/MyriadPro-Regular-18.vlw");
    fontMyriadPro22       = loadFont("fonts/MyriadPro-Regular-22.vlw");
  };
  
  
/*----------------------------------------------------------------------------*/






// molecule actions
  public void initMolecules() {
    moleculeCount = new int[species.length];
    moleculeRoll = new ArrayList();
    //pHRoll = new ArrayList();
    
    molecules = new Molecule[species.length * moleculeQntyMax +1]; // allow molecules up to a certain threshold
    for (int i = 0; i < species.length; i++) {
      // populate molecules[]
      for (int j = 0; j < speciesStartQnty[i]; j++) {
        appendMolecule(species[i]);
      }
    }
  }

  public void appendMolecule(String moleculeName) {
    countMolecules();
    for (int i = 0; i < species.length; i++) {
      if (moleculeName.equals(species[i])) {
        if (moleculeCount[i] < moleculeQntyMax) {
          molecules[moleculeQntyTotal] = new Molecule(moleculeName);
        }
      }
    }
    countMolecules();
  }
  
  public void appendMolecule(String moleculeName, float locX, float locY) {
    countMolecules();
    for (int i = 0; i < species.length; i++) {
      if (moleculeName.equals(species[i])) {
        if (moleculeCount[i] < moleculeQntyMax) {
          molecules[moleculeQntyTotal] = new Molecule(moleculeName, locX, locY);
        }
      }
    }
    countMolecules();
  }
  
  public void removeMolecule(String moleculeName) {
    countMolecules();
    // locate a relevant molecule in array
    int offset = 0;
    while (molecules[offset] != null && !moleculeName.equals(molecules[offset].moleculeName) && offset < molecules.length - 1) {
      offset++;
    }
    for (int i = offset; i < molecules.length - 1; i++) {
      molecules[i] = molecules[i+1];
    }
    countMolecules();
  }
  
  public void removeMoleculeByID(int moleculeToKillID) {
    // locate the relevant molecule in the array
    int offset = 0;
    
    while (molecules[offset].moleculeID != moleculeToKillID) {
      offset++;
    }
    
    // kill molecule
    for (int i = offset; i < molecules.length - 1; i++) {
      molecules[i] = molecules[i+1];
    }
    countMolecules();
  }


// iterate and tabulate totals of all types of atoms
  public void countMolecules() {
    // clear existing count
    for (int i = 0; i < moleculeCount.length; i++) {
      moleculeCount[i] = 0;
    }
    int i = 0;
    while (molecules[i] != null) {
      String mName = molecules[i].moleculeName;
      for (int ii = 0; ii < species.length; ii++) {
        if (mName.equals(species[ii])) {
          moleculeCount[ii]++;
        }
      }
      i++;
    }
    moleculeQntyTotal = i;
  }
  
  public int countMolecules(String molName) {
    for (int i = 0; i < species.length; i++) {
      if (species[i].equals(molName)) {
        return moleculeCount[i];
      }
    }
    return 0;
  }
  
  public int getHighestID() {
    int molID = 0;
    for (int i = 0; i < moleculeQntyTotal; i++) {
      if (molecules[i].moleculeID > molID) {
        molID = molecules[i].moleculeID;
      }
    }
    return molID;
  }
  
  // this function accepts an array of reactant species, and returns the reaction number from a reactions table; if none, it returns -1
  public int getReactionNumber(ArrayList inputMolecules) {
    int reactionNumber = -1;
    // march through reactants lines, to look for a match
    for (int i = 0; i < reactants.length; i++) {
      ArrayList reactantsSplit = new ArrayList(Arrays.asList(reactants[i].split(", ")));
      for (int j = 0; j < inputMolecules.size(); j++) {
        // if all input terms are in the reactions list and the quantity of both is equal
        if (arrayListMatch(inputMolecules, reactantsSplit) == true) {
            reactionNumber = i;
        }
      }
    }
    return reactionNumber;
  }
  
  public boolean arrayListMatch(ArrayList al1, ArrayList al2) {
    // brute force method.
    // for each item in the first array...
    for (int i = 0; i < al1.size(); i++) {
      // check if the second array contains that item...
      if (al2.contains(al1.get(i))) {
        // if the second array contains that item, remove it.
        al2.remove(al2.indexOf(al1.get(i)));
        // if the 2nd array runs out of items to remove, then all items in al1 are in al2
      } else {
        return false;
      }
    }
    // final check: make sure the truncated al2 doesn't have anything left to remove. If so, the two arrays are equal
    if (al2.size() < 1) {
      return true;
    } else {
      return false;
    }
  }
  
  /*float getPH() { 
    float pH;
    float pOH;
    int qntyH3O   = countMolecules("Hydronium");
    int qntyOH    = countMolecules("Hydroxide");
    float totalVolume = float(moleculeQntyTotal) / 1000;

    if (qntyH3O != qntyOH) {
      pH  = log(qntyH3O / totalVolume);
    } else {
      pH = 7;
    }
    return pH;
  }
  
  float getPOH() { 
    float pOH;
    int qntyH3O   = countMolecules("Hydronium");
    int qntyOH    = countMolecules("Hydroxide");
    float totalVolume = float(moleculeQntyTotal) / 1000;

    if (qntyH3O != qntyOH) {
      pOH = log(qntyOH / totalVolume);
    } else {
      pOH = 7;
    }
    return pOH;
  }*/
  
  
  
  public void pauseMolecules() {
    for (int i = 0; i < moleculeQntyTotal; i++) {
      molecules[i].pauseMotion();
    }
  }
  
  public void unpauseMolecules() {
    for (int i = 0; i < moleculeQntyTotal; i++) {
      molecules[i].unpauseMotion();
    }
  }

  
/*----------------------------------------------------------------------------*/
  
// colors
  public void setColors() {};
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "alpha5" });
  }
}
