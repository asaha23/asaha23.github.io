import processing.core.*; 
import processing.xml.*; 

import controlP5.*; 
import de.bezier.data.sql.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class alpha2 extends PApplet {

// Connected Chemistry Curriculum
// Project Leader: Mike Stieff, PhD, University of Illinois at Chicago
// Modeled in Processing by: Allan Berry

// Elemental data courtesy Freebase, via a Creative Commons License
// http://www.freebase.com/view/chemistry/chemical_element
// Accessed 2010-09-08
/*--------------------------------------------------------------------------*/


// Units and Dimensions
/*---------------------*/

// libraries

ControlP5 controlP5;

public SQLite db;

// db
public Table elementTable; // main repository for element data

// modules for graphics, to makes things look even; set up in setup()
public float mod;  // setup a standard module size for graphics... 
public int iMod;   // same as above, but as integer (useful sometimes).

public int mainW;    // window width
public int mainH;    // window height

// fonts
//public PFont fontMonaco12;
//public PFont fontMonaco18;
//public PFont fontMonaco24;
public PFont fontHelvetica12;
public PFont fontHelvetica18;
public PFont fontHelvetica24;



// canvas
public CanvasPanel canvasPanel;
public float canvasScale;
public float speed;
public int moleculeQnty;

public int moleculeQntyMin;
public int moleculeQntyDef;
public int moleculeQntyMax;

// canvas
public GraphPanel graphPanel;

// elements
/*public HashMap elementDBName;
public HashMap elementDBNumber;
public HashMap elementDBSymbol;
public HashMap elementDBColor;
public HashMap elementDBAtomicMass;
public HashMap elementDBAtomicRadius;*/

public void setup() {
  // init
  frameRate(30);
  mod = 48; // see above, in Units and Dimensions
  iMod = floor(mod);  // ..
  
  mainW = iMod * 18;    // window width
  mainH = iMod * 14;    // window height
  
  // database
  /*db = new SQLite(this, "model1.db"); // open database file
  if (db.connect()) {

    elementDBName = new HashMap(100);
    elementDBNumber = new HashMap(100);
    elementDBSymbol = new HashMap(100);
    elementDBColor = new HashMap(100);
    elementDBAtomicMass = new HashMap(100);
    elementDBAtomicRadius = new HashMap(100);
    
    // read all in table "elementsTable"
    db.query( "SELECT * FROM elementsTable");
    
    while (db.next()) {
        elementDBName.put(db.getInt("number"), db.getString("name"));
        elementDBNumber.put(db.getInt("number"), db.getInt("number"));
        elementDBSymbol.put(db.getInt("number"), db.getString("symbol"));
        elementDBColor.put(db.getInt("number"), db.getString("color"));
        elementDBAtomicMass.put(db.getInt("number"), db.getFloat("atomicMass"));
        elementDBAtomicRadius.put(db.getInt("number"), db.getFloat("atomicRadius"));
    }
  }*/
  
  // bootstrap
  smooth();
  // frameRate();
  setColors();
  size(864, 672);
  
  // fontMonaco12 = loadFont("Monaco-12.vlw");
  // fontMonaco18 = loadFont("Monaco-18.vlw");
  // fontMonaco24 = loadFont("Monaco-24.vlw");
  fontHelvetica12 = loadFont("Helvetica-12.vlw");
  fontHelvetica18 = loadFont("Helvetica-18.vlw");
  fontHelvetica24 = loadFont("Helvetica-24.vlw");
  
  // initialize gui widgets
  int canvasPanelW = iMod * 10;
  int canvasPanelH = iMod * 10;
  canvasPanel = new CanvasPanel(mainW - iMod - canvasPanelW, iMod, canvasPanelW, canvasPanelH);

  int graphPanelW = iMod * 5;
  int graphPanelH = iMod * 4;
  graphPanel = new GraphPanel(iMod, iMod * 7, graphPanelW, graphPanelH);
  
  // controlP5 start here
  float scaleMin = .05f;
  float scaleDef = 1;
  float scaleMax = 2;
  
  float speedMin = 0;
  float speedDef = 1;
  float speedMax = 10;
  
  moleculeQntyMin = 0;
  moleculeQntyDef = 5;
  moleculeQntyMax = 100;
  
  canvasScale = scaleDef;
  speed = speedDef;
  moleculeQnty = moleculeQntyDef;
  
  // init
  controlP5 = new ControlP5(this);
  
  controlP5.addSlider("canvasScale",scaleMin,scaleMax,scaleDef,iMod,iMod,iMod * 4,iMod/2);
  controlP5.addSlider("speed",speedMin,speedMax,speedDef,iMod,iMod * 2,iMod * 4,iMod/2);
  controlP5.addSlider("moleculeQnty",moleculeQntyMin,moleculeQntyMax,moleculeQnty,iMod,iMod * 3,iMod * 4,iMod/2);
  
  setColors();  // inits colorSys
  setDefColors(); // inits default colors
}

public void draw() {
  pushStyle();  // provide a background for the visualization
    noStroke();
    fill(cMainBgFillDef);
    rect(0, 0, mainW, mainH); // bg
  popStyle();
  
  canvasPanel.update();
  canvasPanel.display();
  canvasPanel.canvasPanelScale = canvasScale;
  
  graphPanel.update();
  graphPanel.display();
  
  // labelling
  textFont(fontHelvetica24, 24);
  fill(cWt);
  text("Connected Chemistry, model 1, v.1a", mod, mod*13);
  
  textFont(fontHelvetica12, 12);
  fill(cGrLt);
  textAlign(CENTER);
  text("Time", mod*3.5f, mod*11.25f+12);
  textAlign(LEFT);
  text("Qty", mod*6.25f, mod*9 + 6);
  text(str(moleculeQntyMax), mod*6.25f, mod*7+12);
  text(str(moleculeQntyMin), mod*6.25f, mod*11);
}
public class Atom {
  
  public int cAtomFill = cAtomFillDef;
  public int cAtomStrk = cAtomStrkDef;
  
  public float xLoc;
  public float yLoc;
  
  public int atomicNum;
  
  String elementName;
  public float atomicRadius;
  public int atomFillColor;
  public int atomStrkColor;
  
  public int elementID;
  public int ion;
  
  public float scaleRadius;
  
  // Constructor
  public Atom(float xLoc_, float yLoc_, int atomicNum_) {
    
    xLoc = xLoc_;
    yLoc = yLoc_;
    
    atomicNum = atomicNum_;
    
    if (atomicNum == 1) {
      atomicRadius = 53.0f;
      atomFillColor = cWt;
      }
    else if (atomicNum == 8) {
      atomicRadius = 60.0f;
      atomFillColor = cRd;
      }
    else if (atomicNum == 17) {
      atomicRadius = 100;
      atomFillColor = cGn;
      }
      
    /*atomicRadius = int(elementDBAtomicRadius.get(atomicNum).toString());
    elementName = elementDBName.get(atomicNum).toString();
    //atomFillColor = elementDBColor.get(atomicNum).toString();
    println(elementName);*/
  }

  // Main
  public void update() {
    scaleRadius = atomicRadius * canvasPanel.canvasPanelScale;
  };
  public void display() {
    pushStyle();
      stroke(cBkT30);
      fill(atomFillColor);
      ellipse(xLoc, yLoc, scaleRadius, scaleRadius);
    popStyle();
  };
};
public class CanvasPanel extends GuiPanel {
  
  Molecule[] molecules;
  public float canvasPanelScale = .75f;
  
  // Constructor
  
  public CanvasPanel(int widgetX_, int widgetY_, int widgetW_, int widgetH_) {
    super(widgetX_, widgetY_, widgetW_, widgetH_);
    super.panelMask = true;
    
    molecules = new Molecule[moleculeQnty];
    for(int i = 0; i < moleculeQnty; i++) {
      molecules[i] = new Molecule(random(widgetW), random(widgetH), "Water");
    }
  }

  // Main
  public void update() {
    if (moleculeQnty == molecules.length) {
    } else if (moleculeQnty > molecules.length) {
      while (moleculeQnty > molecules.length) {
        addMolecule();
      }
    } else if (moleculeQnty < molecules.length) {
      while (moleculeQnty < molecules.length) {
        removeMolecule();
      }
    }
  };
  public void display() {
    super.drawFill();
    pushMatrix();
    translate(widgetX, widgetY);
      for(int i = 0; i < moleculeQnty; i++) {
        molecules[i].update();
        molecules[i].display();
      }
    popMatrix();
    super.drawMask();
    super.drawStrk();
  };
  
  public void addMolecule() {
    molecules = (Molecule[])append(molecules, new Molecule(random(widgetW), random(widgetH), "Water"));
  };
  public void removeMolecule() {
    molecules = (Molecule[])shorten(molecules);
  };
  
};
public class GraphPanel extends GuiPanel {
  
  int elapsedFrames = 0;
  
  float minX;
  float maxX;
  float minY;
  float maxY;
  
  int[] graphPoints;
  int[] graphPointsPrevious;
  
  public GraphPanel(int widgetX_, int widgetY_, int widgetW_, int widgetH_) {
    super(widgetX_, widgetY_, widgetW_, widgetH_);
    
    graphPoints = new int[widgetW];
    graphPointsPrevious = new int[widgetW];
  }

  // Main
  public void update() {
  }
  public void display() {
    super.drawFill();
    
    pushMatrix();
    pushStyle();
    translate(widgetX, widgetY);
      fill(cRd);
      for (int i = 0; i < graphPoints.length-1; i++) {
        graphPointsPrevious[i] = graphPoints[i];
      }
      graphPoints[0] = moleculeQnty;
      for (int i = 1; i < graphPoints.length; i++) {
        graphPoints[i] = graphPointsPrevious[i-1];
      }
      for (int i = 0; i < widgetW; i++) {
          ellipse(widgetW - i, map(graphPoints[i], moleculeQntyMax, moleculeQntyMin, 0, widgetH), 3, 3);
      }
    popStyle();
    popMatrix();
    super.drawMask();
    super.drawStrk();
  }
}
public class GuiPanel {
  // class variables
  public int widgetX; // X coordinates of layer
  public int widgetY; // Y coordinates of layer
  public int widgetW; // width of layer
  public int widgetH; // height of layer
  
  // for use in masks
  public int widgetT;  // space above object
  public int widgetR;  // space to right of object
  public int widgetB;  // space below object
  public int widgetL;  // space to left of object
  public boolean panelMask = false; // panel mask off by default
  
  // Constructor
  public GuiPanel(int widgetX_, int widgetY_, int widgetW_, int widgetH_) {
    widgetX = widgetX_;
    widgetY = widgetY_;
    widgetW = widgetW_;
    widgetH = widgetH_;
    
    widgetR = widgetX + widgetW;  // right edge of widget
    widgetB = widgetY + widgetH;  // bottom edge of widget
    
  }

  // Main
  public void drawFill() {
    pushMatrix();
    translate(widgetX, widgetY);
    pushStyle();
      noStroke();
      fill(cWidgetFillDef);
      rect(0, 0, widgetW, widgetH); // widget outlines
    popStyle();
    popMatrix();
  };
  public void drawMask() {  // I plan to replace this kludgy solution later with something pixel-based
    if (panelMask == true) {
      pushStyle();
        noStroke();
        fill(cMainBgFillDef);
        rect(0, 0, mainW, widgetY); // top mask
        rect(widgetR, 0, mainW - widgetR, mainH); // right mask
        rect(0, widgetB, mainW, mainH-widgetB); // bottom mask
        rect(0, 0, widgetX, mainH); // left mask
      popStyle();
    };
  };
  public void drawStrk() {
    pushMatrix();
    translate(widgetX, widgetY);
    pushStyle();
      noFill();
      stroke(cWidgetStrkDef);
      rect(0, 0, widgetW, widgetH); // widget outlines
    popStyle();
    popMatrix();
  };
};
public class Molecule {
  
  public float xLoc;
  public float yLoc;
  public String moleculeName;
  
  public int atomQnty;
  
  // movement variables
  public float xDir = 1; // direction
  public float yDir = 1; // direction
  public float vel; // velocity
  public float acc; // acceleration
  public float rotation = random(0, 2); // rotation: default .2 rad, i.e. 1 rotation/second
  public float rotationRate = .1f;
  
  public Atom[] atoms;
  
  // Constructor
  public Molecule(float xLoc_, float yLoc_, String moleculeName_) {
    xLoc = xLoc_;
    yLoc = yLoc_;
    moleculeName = moleculeName_;
    
    if (moleculeName == "Water") {initWater();}
    if (moleculeName == "Hydrogen Chloride") {initHydrogenChloride();}
  };

  // Main
  public void update() {
    // motion
    
    if (xLoc != 0 && (xLoc >= canvasPanel.widgetW || xLoc <= 0)) {
      xDir = xDir * -1;
    }
    if (yLoc != 0 && (yLoc >= canvasPanel.widgetH || yLoc <= 0)) {
      yDir = yDir * -1;
    }
    xLoc = xLoc + xDir * speed;
    yLoc = yLoc + yDir * speed;
    
    // settle 2D atomic geometry
    if (moleculeName == "Water") {updateWater();}
    if (moleculeName == "Hydrogen Chloride") {updateHydrogenChloride();}
    
  };
  public void display() {
    pushMatrix();
    pushStyle();
    translate(xLoc, yLoc);
      rotate(rotation);      
      rotation = rotation + rotationRate;
      for(int i = 0; i < atomQnty; i++) {
        atoms[i].update();
        atoms[i].display();
      }
      
    popStyle();
    popMatrix();
  };
  
  public void initWater() {
    atomQnty = 3;
    atoms = new Atom[atomQnty];
    atoms[0] = new Atom(0, 0, 8);
    atoms[1] = new Atom(0, 0, 1);
    atoms[2] = new Atom(0, 0, 1);
  }
  public void updateWater() {
    float atomOffset = atoms[0].atomicRadius*.75f * canvasPanel.canvasPanelScale;
    float atomAngle = 104.45f;  // atom angle
    float hypotenuse = atomOffset;
    float theta = atomAngle - 90;
    float xOffset = sin(theta) * hypotenuse;
    float yOffset = cos(theta) * hypotenuse * -1;
    atoms[1].xLoc = 0; 
    atoms[1].yLoc = hypotenuse * -1;
    atoms[2].xLoc = xOffset;
    atoms[2].yLoc = yOffset;
  }
  
  public void initHydrogenChloride() {
    atomQnty = 2;
    atoms = new Atom[atomQnty];
    atoms[0] = new Atom(0, 0, 1);
    atoms[1] = new Atom(0, 0, 17);
  }
  public void updateHydrogenChloride() {
    float atomOffset = atoms[0].atomicRadius*1.25f * canvasPanel.canvasPanelScale;
    atoms[1].xLoc = atomOffset; 
    atoms[1].yLoc = 0;
  }
};
// This code from the Processing Table class.  Has not been altered.

class Table {
  int rowCount;
  String[][] data;


  Table(String filename) {
    String[] rows = loadStrings(filename);
    data = new String[rows.length][];

    for (int i = 0; i < rows.length; i++) {
      if (trim(rows[i]).length() == 0) {
        continue; // skip empty rows
      }
      if (rows[i].startsWith("#")) {
        continue;  // skip comment lines
      }

      // split the row on the tabs
      String[] pieces = split(rows[i], TAB);
      // copy to the table array
      data[rowCount] = pieces;
      rowCount++;

      // this could be done in one fell swoop via:
      //data[rowCount++] = split(rows[i], TAB);
    }
    // resize the 'data' array as necessary
    data = (String[][]) subset(data, 0, rowCount);
  }


  public int getRowCount() {
    return rowCount;
  }


  // find a row by its name, returns -1 if no row found
  public int getRowIndex(String name) {
    for (int i = 0; i < rowCount; i++) {
      if (data[i][0].equals(name)) {
        return i;
      }
    }
    println("No row named '" + name + "' was found");
    return -1;
  }


  public String getRowName(int row) {
    return getString(row, 0);
  }


  public String getString(int rowIndex, int column) {
    return data[rowIndex][column];
  }


  public String getString(String rowName, int column) {
    return getString(getRowIndex(rowName), column);
  }


  public int getInt(String rowName, int column) {
    return parseInt(getString(rowName, column));
  }


  public int getInt(int rowIndex, int column) {
    return parseInt(getString(rowIndex, column));
  }


  public float getFloat(String rowName, int column) {
    return parseFloat(getString(rowName, column));
  }


  public float getFloat(int rowIndex, int column) {
    return parseFloat(getString(rowIndex, column));
  }


  public void setRowName(int row, String what) {
    data[row][0] = what;
  }


  public void setString(int rowIndex, int column, String what) {
    data[rowIndex][column] = what;
  }


  public void setString(String rowName, int column, String what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = what;
  }


  public void setInt(int rowIndex, int column, int what) {
    data[rowIndex][column] = str(what);
  }


  public void setInt(String rowName, int column, int what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = str(what);
  }


  public void setFloat(int rowIndex, int column, float what) {
    data[rowIndex][column] = str(what);
  }


  public void setFloat(String rowName, int column, float what) {
    int rowIndex = getRowIndex(rowName);
    data[rowIndex][column] = str(what);
  }  
}


// this file is a central place to define colors in the visualization

public int cMainBgFillDef;

public int cWidgetFillDef;
public int cWidgetStrkDef;

public int cAtomFillDef;
public int cAtomStrkDef;

public void setDefColors() {
  cMainBgFillDef = cGrDk;

  cWidgetFillDef = cBkT20;
  cWidgetStrkDef = cGr;

  cAtomFillDef    = cGr;
  cAtomStrkDef    = cGrLt;
};
/* The Allan Berry Color System
 This is a simple, reusable color system for Processing.  It works in a
 modular fashion, by combining two-letter sets together for color names, 
 with each set prefixed by a "c" to avoid potential name clashes.
 
 It doesn't attempt to depict every color in the known spectrum... merely
 instead a standard set of "crayola" colors for use in most environments.
 
 Order matters, of course.  First comes the primary colors, then the 
 secondary or tertiary colors, if any.  This is followed by any further
 color characteristics, like Lt (light) or Dk (dark).
 
 Rd  Red
 Or  Orange
 Yl  Yellow
 Gn  Green
 Bl  Blue
 Vt  Violet
 
 Gr  Gray
 Bk  Black
 Wt  White
 
 Br  Brown
 Sn  Sienna
 Oc  Ochre
 Um  Umber
 */

public int cBk       ;
public int cBkT10    ;
public int cBkT20    ;
public int cBkT30    ;
public int cBkT40    ;
public int cBkT50    ;
public int cBkT60    ;
public int cBkT70    ;
public int cBkT80    ;
public int cBkT90    ;
public int cBl       ;
public int cBlDk     ;
public int cBlGn     ;
public int cBlGnDk   ;
public int cBlGnLt   ;
public int cBlLt     ;
public int cBlT10;
public int cBlT20;
public int cBlT30;
public int cBlT40;
public int cBlT50;
public int cBlT60;
public int cBlT70;
public int cBlT80;
public int cBlT90;
public int cBlVt     ;
public int cBlVtDk   ;
public int cBlVtLt   ;
public int cBrOc     ;
public int cBrSn     ;
public int cBrUm     ;
public int cCl       ;
public int cGn       ;
public int cGnDk     ;
public int cGnLt     ;
public int cGnT10;
public int cGnT20;
public int cGnT30;
public int cGnT40;
public int cGnT50;
public int cGnT60;
public int cGnT70;
public int cGnT80;
public int cGnT90;
public int cGr       ;
public int cGrBl     ;
public int cGrDk     ;
public int cGrLt     ;
public int cGrOc     ;
public int cGrSn     ;
public int cGrUm     ;
public int cOr       ;
public int cOrDk     ;
public int cOrLt     ;
public int cRd       ;
public int cRdDk     ;
public int cRdLt     ;
public int cRdOr     ;
public int cRdOrDk   ;
public int cRdOrLt   ;
public int cRdT10;
public int cRdT20;
public int cRdT30;
public int cRdT40;
public int cRdT50;
public int cRdT60;
public int cRdT70;
public int cRdT80;
public int cRdT90;
public int cRdVt     ;
public int cRdVtDk   ;
public int cRdVtLt   ;
public int cVt       ;
public int cVtDk     ;
public int cVtLt     ;
public int cWt       ;
public int cWtT10    ;
public int cWtT20    ;
public int cWtT30    ;
public int cWtT40    ;
public int cWtT50    ;
public int cWtT60    ;
public int cWtT70    ;
public int cWtT80    ;
public int cWtT90    ;
public int cYl       ;
public int cYlDk     ;
public int cYlGn     ;
public int cYlGnDk   ;
public int cYlGnLt   ;
public int cYlLt     ;
public int cYlOr     ;
public int cYlOrDk   ;
public int cYlOrLt   ;


public void setColors() {
  colorMode(HSB, 360, 100, 100, 100);

  // root colors
  float rRd   =   0;
  float rRdOr =  25;
  float rOr   =  35;
  float rYlOr =  47;
  float rYl   =  60;
  float rYlGn =  85;
  float rGn   = 130;
  float rBlGn = 170;
  float rBl   = 210;
  float rBlVt = 250;
  float rVt   = 270;
  float rRdVt = 310;

  // saturated colors
  cRd       = color(rRd  , 100,  90);   // Red
  cRdOr     = color(rRdOr, 100,  80);   // Red-Orange
  cOr       = color(rOr  , 100,  75);   // Orange
  cYlOr     = color(rYlOr, 100,  70);   // Yellow-Orange
  cYl       = color(rYl  , 100,  70);   // Yellow
  cYlGn     = color(rYlGn, 100,  75);   // Yellow-Green
  cGn       = color(rGn  , 100,  80);   // Green
  cBlGn     = color(rBlGn, 100,  90);   // Blue-Green
  cBl       = color(rBl  , 100, 100);   // Blue
  cBlVt     = color(rBlVt, 100, 100);   // Blue-Violet
  cVt       = color(rVt  , 100, 100);   // Violet
  cRdVt     = color(rRdVt, 100, 100);   // Red-Violet

  cRdLt     = color(rRd  ,  75, 100);   // Red (light)
  cRdOrLt   = color(rRdOr,  75, 100);   // Red-Orange (light)
  cOrLt     = color(rOr  ,  75, 100);   // Orange (light)
  cYlOrLt   = color(rYlOr,  75, 100);   // Yellow-Orange (light)
  cYlLt     = color(rYl  ,  75, 100);   // Yellow (light)
  cYlGnLt   = color(rYlGn,  75, 100);   // Yellow-Green (light)
  cGnLt     = color(rGn  ,  75, 100);   // Green (light)
  cBlGnLt   = color(rBlGn,  75, 100);   // Blue-Green (light)
  cBlLt     = color(rBl  ,  75, 100);   // Blue (light)
  cBlVtLt   = color(rBlVt,  75, 100);   // Blue-Violet (light)
  cVtLt     = color(rVt  ,  75, 100);   // Violet (light)
  cRdVtLt   = color(rRdVt,  75, 100);   // Red-Violet (light)

  cRdDk     = color(rRd  , 75,  50);   // Red (dark)
  cRdOrDk   = color(rRdOr, 75,  50);   // Red-Orange (dark)
  cOrDk     = color(rOr  , 75,  50);   // Orange (dark)
  cYlOrDk   = color(rYlOr, 75,  50);   // Yellow-Orange (dark)
  cYlDk     = color(rYl  , 75,  50);   // Yellow (dark)
  cYlGnDk   = color(rYlGn, 75,  50);   // Yellow-Green (dark)
  cGnDk     = color(rGn  , 75,  50);   // Green (dark)
  cBlGnDk   = color(rBlGn, 75,  50);   // Blue-Green (dark)
  cBlDk     = color(rBl  , 75,  50);   // Blue (dark)
  cBlVtDk   = color(rBlVt, 75,  50);   // Blue-Violet (dark)
  cVtDk     = color(rVt  , 75,  50);   // Violet (dark)
  cRdVtDk   = color(rRdVt, 75,  50);   // Red-Violet (dark)

  // browns
  cBrSn     = color( 30, 100,  50);   // Brown-Sienna
  cBrOc     = color( 40, 100,  75);   // Brown-Ochre
  cBrUm     = color( 50, 100,  25);   // Brown-Umber

  // grays
  cBk       = color(  0,   0,   0);   // Black
  cWt       = color(  0,   0, 100);   // White

  cGrLt     = color(  0,   0,  65);   // Gray-Light
  cGr       = color(  0,   0,  50);   // Gray
  cGrDk     = color(  0,   0,  35);   // Gray-Dark

  cGrBl     = color(240,  25,  50);   // Gray-Blue
  cGrSn     = color( 30,  25,  50);   // Gray-Sienna
  cGrOc     = color( 40,  25,  50);   // Gray-Ochre
  cGrUm     = color( 50,  25,  50);   // Gray-Umber

  // clear
  cCl = color(0, 1); // (almost) clear... color(0, 0) renders black for some reason

  // transparent blacks
  cBkT10    = color(0, 10);  // 10% transparent black
  cBkT20    = color(0, 20);  // 20% transparent black
  cBkT30    = color(0, 30);  // 30% transparent black
  cBkT40    = color(0, 40);  // 40% transparent black
  cBkT50    = color(0, 50);  // 50% transparent black
  cBkT60    = color(0, 60);  // 60% transparent black
  cBkT70    = color(0, 70);  // 70% transparent black
  cBkT80    = color(0, 80);  // 80% transparent black
  cBkT90    = color(0, 90);  // 90% transparent black

  // transparent whites
  cWtT10    = color(255, 10);  // 10% transparent white
  cWtT20    = color(255, 20);  // 20% transparent white
  cWtT30    = color(255, 30);  // 30% transparent white
  cWtT40    = color(255, 40);  // 40% transparent white
  cWtT50    = color(255, 50);  // 50% transparent white
  cWtT60    = color(255, 60);  // 60% transparent white
  cWtT70    = color(255, 70);  // 70% transparent white
  cWtT80    = color(255, 80);  // 80% transparent white
  cWtT90    = color(255, 90);  // 90% transparent white

  // transparent reds
  cRdT10       = color(rRd  , 100,  90, 10);   //  10% transparent Red
  cRdT20       = color(rRd  , 100,  90, 20);   //  20% transparent Red
  cRdT30       = color(rRd  , 100,  90, 30);   //  30% transparent Red
  cRdT40       = color(rRd  , 100,  90, 40);   //  40% transparent Red
  cRdT50       = color(rRd  , 100,  90, 50);   //  50% transparent Red
  cRdT60       = color(rRd  , 100,  90, 60);   //  60% transparent Red
  cRdT70       = color(rRd  , 100,  90, 70);   //  70% transparent Red
  cRdT80       = color(rRd  , 100,  90, 80);   //  80% transparent Red
  cRdT90       = color(rRd  , 100,  90, 90);   //  90% transparent Red

  // transparent greens
  cGnT10       = color(rGn  , 100,  80, 10);   //  10% transparent Green
  cGnT20       = color(rGn  , 100,  80, 20);   //  20% transparent Green
  cGnT30       = color(rGn  , 100,  80, 30);   //  30% transparent Green
  cGnT40       = color(rGn  , 100,  80, 40);   //  40% transparent Green
  cGnT50       = color(rGn  , 100,  80, 50);   //  50% transparent Green
  cGnT60       = color(rGn  , 100,  80, 60);   //  60% transparent Green
  cGnT70       = color(rGn  , 100,  80, 70);   //  70% transparent Green
  cGnT80       = color(rGn  , 100,  80, 80);   //  80% transparent Green
  cGnT90       = color(rGn  , 100,  80, 90);   //  90% transparent Green

  // transparent blues
  cBlT10       = color(rBl  , 100,  100, 10);   //  10% transparent Blue
  cBlT20       = color(rBl  , 100,  100, 20);   //  20% transparent Blue
  cBlT30       = color(rBl  , 100,  100, 30);   //  30% transparent Blue
  cBlT40       = color(rBl  , 100,  100, 40);   //  40% transparent Blue
  cBlT50       = color(rBl  , 100,  100, 50);   //  50% transparent Blue
  cBlT60       = color(rBl  , 100,  100, 60);   //  60% transparent Blue
  cBlT70       = color(rBl  , 100,  100, 70);   //  70% transparent Blue
  cBlT80       = color(rBl  , 100,  100, 80);   //  80% transparent Blue
  cBlT90       = color(rBl  , 100,  100, 90);   //  90% transparent Blue
  
  /*
  // named colors
  cRed
  cOrange
  cYellow
  cGreen
  cBlue
  cViolet
  
  // pastels
  cPink
  cLemon
  cLime
  cAqua
  cFuchsia
  
  // jeweltones
  cCrimson
  cTeal
  cIndigo
  cPurple
  */
  

  colorMode(RGB);                              
};


  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "alpha2" });
  }
}
